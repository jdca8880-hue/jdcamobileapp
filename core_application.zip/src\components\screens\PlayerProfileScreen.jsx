import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Star, MapPin, Award, Activity, TrendingUp, Sliders, Calendar, ShieldCheck, CheckCircle2, Trash2
} from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { api } from '../../lib/api';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const ProfileTabs = ({ tabs, active, onChange }) => (
  <div className="flex bg-slate-100 p-1 rounded-xl mb-4 max-w-xl mx-auto">
    {tabs.map(tab => (
      <button
        key={tab.id}
        onClick={() => onChange(tab.id)}
        className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
          active === tab.id ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        {tab.label}
      </button>
    ))}
  </div>
);

export default function PlayerProfileScreen() {
  const { selectedPlayer, goBack, shortlistedIds, toggleShortlist, userRole, setPlayers } = useCricket();
  const [activeTab, setActiveTab] = useState('Overview');
  const [isDeleting, setIsDeleting] = useState(false);
  const [matchStats, setMatchStats] = useState({ batting: [], bowling: [] });

  const player = selectedPlayer;

  useEffect(() => {
    if (player?.id) {
      api.getPlayerMatchStats(player.id).then(setMatchStats).catch(console.error);
    }
  }, [player?.id]);
  
  if (!player) {
    return (
      <div className="pb-20 bg-[#f8fafc] min-h-screen flex flex-col items-center justify-center p-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 text-center max-w-md w-full">
          <h2 className="text-xl font-bold text-slate-800 mb-2">No Player Selected</h2>
          <p className="text-sm text-slate-500 mb-4">Please select a player from the directory to view their profile.</p>
          <button 
            onClick={goBack}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition w-full"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const isShortlisted = shortlistedIds?.includes(player.id);

  const tabs = [
    { id: 'Overview', label: 'Stats' },
    { id: 'Batting', label: 'Batting' },
    { id: 'Bowling', label: 'Bowling' },
    { id: 'Selection', label: 'History' },
  ];

  const handleDelete = async () => {
    if (!window.confirm("Are you sure you want to delete this player? They will be moved to the Recycle Bin.")) return;
    setIsDeleting(true);
    try {
      const { api } = await import('../../lib/api');
      await api.deletePlayer(player.id);
      
      try {
        const { db } = await import('../../lib/db');
        await db.players.delete(player.id);
      } catch (e) {
        console.error("Failed to delete from local DB:", e);
      }
      
      if (setPlayers) {
        setPlayers(prev => prev.filter(p => p.id !== player.id));
      }
      
      alert('Player deleted successfully.');
      goBack();
    } catch (err) {
      console.error(err);
      alert('Failed to delete player.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="pb-20 bg-[#f8fafc] min-h-screen">
      {/* Header Area */}
      <div className="bg-white border-b border-slate-200 pt-14 sm:pt-6 pb-6 px-4 relative shadow-2xs">
        <div className="max-w-4xl mx-auto relative">
          <button
            onClick={goBack}
            className="absolute top-0 left-0 w-9 h-9 flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition cursor-pointer"
            aria-label="Go Back"
          >
            <ArrowLeft size={18} />
          </button>

          <button
            onClick={() => toggleShortlist(player.id)}
            className={`absolute top-0 right-0 w-9 h-9 flex items-center justify-center rounded-lg border transition cursor-pointer ${
              isShortlisted
                ? 'bg-amber-50 border-amber-200 text-amber-600'
                : 'bg-white border-slate-200 text-slate-400 hover:text-slate-600'
            }`}
            aria-label="Toggle Shortlist"
          >
            <Star size={18} fill={isShortlisted ? '#d97706' : 'none'} />
          </button>

          {userRole === 'SUPER_ADMIN' && (
            <button
              onClick={handleDelete}
              disabled={isDeleting}
              className="absolute top-0 right-11 w-9 h-9 flex items-center justify-center rounded-lg border bg-white border-rose-200 text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition cursor-pointer disabled:opacity-50"
              title="Delete Player"
            >
              <Trash2 size={16} />
            </button>
          )}

          <div className="flex flex-col items-center mt-2 text-center">
            <img
              src={player.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(player.full_name || player.full_name || 'Player')}&background=random`}
              alt={player.full_name}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-2 border-white shadow-sm mb-3"
            />
            <h1 className="text-xl sm:text-2xl font-semibold text-slate-900 leading-tight mb-1">
              {player.full_name}
            </h1>
            <div className="text-xs text-slate-500 flex items-center justify-center gap-1.5 mb-3">
              <span className="font-medium text-slate-700">{player.primary_role}</span>
              <span>•</span>
              <MapPin size={12} className="text-blue-600" />
              <span>{player.district}</span>
              <span>•</span>
              <span>{player.team || 'District XI'}</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-700 text-xs font-medium border border-blue-100">
                {player.category || 'Senior'}
              </span>
              <span className="px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 text-xs font-medium border border-emerald-100 flex items-center gap-1">
                <ShieldCheck size={12} /> Registered
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-5">
        <ProfileTabs tabs={tabs} active={activeTab} onChange={setActiveTab} />

        {/* Content Area */}
        <div className="space-y-4">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'Overview' && (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
                  <div className="text-xs font-medium text-slate-400">Career Runs</div>
                  <div className="text-xl sm:text-2xl font-semibold text-blue-700 mt-1">
                    {player.careerRuns || 0}
                  </div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
                  <div className="text-xs font-medium text-slate-400">Batting Average</div>
                  <div className="text-xl sm:text-2xl font-semibold text-slate-900 mt-1">
                    {player.battingAvg ? player.battingAvg : '-'}
                  </div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
                  <div className="text-xs font-medium text-slate-400">Strike Rate</div>
                  <div className="text-xl sm:text-2xl font-semibold text-slate-900 mt-1">
                    {player.strikeRate || '-'}
                  </div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
                  <div className="text-xs font-medium text-slate-400">Wickets</div>
                  <div className="text-xl sm:text-2xl font-semibold text-slate-900 mt-1">
                    {player.wickets || 0}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                  <Award size={16} className="text-amber-500" />
                  <h3 className="font-semibold text-sm text-slate-900">Distinctions & Honors</h3>
                </div>
                <ul className="space-y-2 text-xs">
                  {(player.awards || []).map((award, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                      <span>{award}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </>
          )}

          {/* TAB 2: BATTING */}
          {activeTab === 'Batting' && (
            <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-100 bg-slate-50/60 flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-sm text-slate-900">Batting Profile</h3>
                  <p className="text-xs text-slate-500">{player.batting_style || '-'}</p>
                </div>
              </div>
              <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <div className="text-xs font-medium text-slate-400">Matches</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.matches || 0}</div>
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-400">Highest Score</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.highScore || 0}</div>
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-400">50s / 100s</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.fifties || 0} / {player.hundreds || 0}</div>
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-400">4s / 6s</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.fours || 0} / {player.sixes || 0}</div>
                </div>
              </div>
              
              {/* Batting Chart */}
              {matchStats.batting.length > 0 && (
                <div className="p-4 border-t border-slate-100">
                  <h4 className="font-semibold text-sm text-slate-800 mb-4">Match-by-Match Runs</h4>
                  <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={matchStats.batting}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="date" tick={{fontSize: 10}} tickMargin={10} minTickGap={15} />
                        <YAxis tick={{fontSize: 10}} />
                        <Tooltip 
                          contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', fontSize: '12px'}}
                          labelStyle={{fontWeight: 'bold', color: '#0f172a', marginBottom: '4px'}}
                        />
                        <Line type="monotone" dataKey="runs_scored" name="Runs" stroke="#f59e0b" strokeWidth={3} dot={{r: 4, fill: '#f59e0b', strokeWidth: 0}} activeDot={{r: 6}} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BOWLING */}
          {activeTab === 'Bowling' && (
            <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-100 bg-slate-50/60 flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-sm text-slate-900">Bowling Profile</h3>
                  <p className="text-xs text-slate-500">{player.bowling_style || '-'}</p>
                </div>
              </div>
              <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <div className="text-xs font-medium text-slate-400">Wickets</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.wickets || 0}</div>
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-400">Economy</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.economy || '-'}</div>
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-400">Best Figures</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.bestBowling || '-'}</div>
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-400">Average</div>
                  <div className="text-lg font-semibold text-slate-900 mt-0.5">{player.bowlingAvg || '-'}</div>
                </div>
              </div>

              {/* Bowling Chart */}
              {matchStats.bowling.length > 0 && (
                <div className="p-4 border-t border-slate-100">
                  <h4 className="font-semibold text-sm text-slate-800 mb-4">Match-by-Match Wickets</h4>
                  <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={matchStats.bowling}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="date" tick={{fontSize: 10}} tickMargin={10} minTickGap={15} />
                        <YAxis tick={{fontSize: 10}} allowDecimals={false} />
                        <Tooltip 
                          contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', fontSize: '12px'}}
                          labelStyle={{fontWeight: 'bold', color: '#0f172a', marginBottom: '4px'}}
                        />
                        <Line type="monotone" dataKey="wickets_taken" name="Wickets" stroke="#3b82f6" strokeWidth={3} dot={{r: 4, fill: '#3b82f6', strokeWidth: 0}} activeDot={{r: 6}} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SELECTION */}
          {activeTab === 'Selection' && (
            <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-100 bg-slate-50/60">
                <h3 className="font-semibold text-sm text-slate-900">Official Selection History</h3>
              </div>
              
              <div className="p-8 text-center text-slate-500 text-sm">
                No selection history available.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
