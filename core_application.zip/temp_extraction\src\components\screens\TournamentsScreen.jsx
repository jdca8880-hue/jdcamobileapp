import React, { useMemo, useState } from 'react';
import { Plus, Search, Trophy, ChevronDown, ChevronRight, FolderOpen, CalendarDays } from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { PageHeader, TabBar } from '../ui/PageHeader';
import MatchFolder from '../ui/MatchFolder';

const TABS = [
  { id: 'all', label: 'All Tournaments' },
  { id: 'active', label: 'Active' },
  { id: 'completed', label: 'Completed' },
  { id: 'create', label: '+ Create' },
];

function CreateTournamentForm({ onCancel }) {
  const [form, setForm] = useState({ name:'', category:'Senior', format:'T20', ball:'White Ball', startDate:'', endDate:'', venue:'', teams:9 });
  const update=(k,v)=>setForm(f=>({...f,[k]:v}));
  return <div className="tournament-create-panel">
    <div className="section-kicker"><Trophy size={15}/> NEW TOURNAMENT</div>
    <h2>Create official JDCA tournament</h2>
    <p>Set the competition structure once. Matches created under it become folders inside the tournament directory.</p>
    <div className="tournament-create-grid">
      <label>Tournament name<input value={form.name} onChange={e=>update('name',e.target.value)} placeholder="e.g. JDCA Senior Division 2026"/></label>
      <label>Category<select value={form.category} onChange={e=>update('category',e.target.value)}><option>Senior</option><option>Under-22</option><option>Under-18</option><option>Under-15</option><option>Under-13</option><option>Women's Senior</option><option>Women's Under-22</option><option>Women's Under-18</option></select></label>
      <label>Format<select value={form.format} onChange={e=>update('format',e.target.value)}><option>T20</option><option>50 Overs</option><option>40 Overs</option><option>30 Overs</option></select></label>
      <label>Ball type<select value={form.ball} onChange={e=>update('ball',e.target.value)}><option>White Ball</option><option>Red Ball</option></select></label>
      <label>Start date<input type="date" value={form.startDate} onChange={e=>update('startDate',e.target.value)}/></label>
      <label>End date<input type="date" value={form.endDate} onChange={e=>update('endDate',e.target.value)}/></label>
      <label>Primary venue<input value={form.venue} onChange={e=>update('venue',e.target.value)} placeholder="JDCA ground"/></label>
      <label>Number of teams<input type="number" value={form.teams} onChange={e=>update('teams',e.target.value)}/></label>
    </div>
    <div className="tournament-create-actions"><button className="btn-primary"><Plus size={15}/> Create Tournament</button><button className="btn-secondary" onClick={onCancel}>Cancel</button></div>
  </div>;
}

export default function TournamentsScreen() {
  const { matches=[], setActiveMatchId, navigateTo } = useCricket();
  const [tab,setTab]=useState('all');
  const [search,setSearch]=useState('');
  const [open,setOpen]=useState({});

  const groups=useMemo(()=>{
    const map=new Map();
    matches.forEach(m=>{ const n=m.tournament||'JDCA Official Fixtures'; if(!map.has(n)) map.set(n,[]); map.get(n).push(m); });
    return [...map.entries()].filter(([name,ms])=>{
      if(!name.toLowerCase().includes(search.toLowerCase())) return false;
      const active=ms.some(m=>['LIVE','IN_PROGRESS'].includes(m.status));
      const completed=ms.every(m=>['COMPLETED','FINISHED'].includes(m.status));
      if(tab==='active') return active;
      if(tab==='completed') return completed;
      return true;
    });
  },[matches,search,tab]);

  const openMatch=(m,section)=>{ setActiveMatchId(m.id); navigateTo(section==='live'?'scoring':'match-detail'); };

  return <div className="tournaments-directory-page">
    <PageHeader title="Tournament Directory" subtitle="Competition → stage → match → complete digital match record" action={<button className="btn-primary" onClick={()=>setTab('create')}><Plus size={16}/> New Tournament</button>}/>
    <div className="matches-toolbar"><div className="matches-search"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search tournament"/></div><TabBar tabs={TABS} active={tab} onChange={setTab}/></div>
    {tab==='create' ? <CreateTournamentForm onCancel={()=>setTab('all')}/> : <div className="tournament-directory-tree">
      {groups.map(([name,ms],i)=>{const isOpen=open[name]??true; const live=ms.filter(m=>['LIVE','IN_PROGRESS'].includes(m.status)).length; const completed=ms.filter(m=>['COMPLETED','FINISHED'].includes(m.status)).length; return <section className="tournament-directory" key={name}>
        <button className="tournament-directory__header" onClick={()=>setOpen(s=>({...s,[name]:!isOpen}))}><span className="tournament-directory__icon"><FolderOpen size={19}/></span><span><small>JDCA TOURNAMENT FOLDER {String(i+1).padStart(2,'0')}</small><strong>{name}</strong><em>{ms.length} matches · {completed} completed {live?`· ${live} live`:''}</em></span>{isOpen?<ChevronDown size={18}/>:<ChevronRight size={18}/>}</button>
        {isOpen&&<div className="tournament-directory__body"><div className="tournament-directory__meta"><span><CalendarDays size={13}/> Match directory</span><b>{ms.length} fixtures</b></div>{ms.map(m=><MatchFolder key={m.id} match={m} onOpen={openMatch}/>)}</div>}
      </section>})}
    </div>}
  </div>;
}
