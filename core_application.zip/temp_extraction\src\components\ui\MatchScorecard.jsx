import React from 'react';

function BattingTable({ team, players = [] }) {
  return <div className="match-scorecard__section">
    <div className="match-scorecard__section-head"><span>{team}</span><strong>{players.reduce((s,p)=>s+(Number(p.runs)||0),0) || '—'}</strong></div>
    <div className="match-scorecard__table">
      <div className="match-scorecard__row match-scorecard__row--head"><span>Batter</span><span>R</span><span>B</span><span>4s</span><span>6s</span><span>SR</span></div>
      {(players.length ? players : [{name:'Batting card generated from deliveries'}]).map((p,i) => <div className="match-scorecard__row" key={p.id || i}><span><b>{p.name}</b><small>{p.dismissal || (p.notOut ? 'not out' : '')}</small></span><span>{p.runs ?? '—'}</span><span>{p.balls ?? '—'}</span><span>{p.fours ?? '—'}</span><span>{p.sixes ?? '—'}</span><span>{p.strikeRate ?? '—'}</span></div>)}
    </div>
  </div>;
}

function BowlingTable({ team, bowlers = [] }) {
  return <div className="match-scorecard__section match-scorecard__bowling">
    <div className="match-scorecard__section-head"><span>{team} Bowling</span></div>
    <div className="match-scorecard__table">
      <div className="match-scorecard__row match-scorecard__row--bowl-head"><span>Bowler</span><span>O</span><span>M</span><span>R</span><span>W</span><span>Econ</span></div>
      {(bowlers.length ? bowlers : [{name:'Bowling figures generated from deliveries'}]).map((p,i) => <div className="match-scorecard__row match-scorecard__row--bowl" key={p.id || i}><span><b>{p.name}</b></span><span>{p.overs ?? '—'}</span><span>{p.maidens ?? '—'}</span><span>{p.runs ?? '—'}</span><span>{p.wickets ?? '—'}</span><span>{p.economy ?? '—'}</span></div>)}
    </div>
  </div>;
}

export default function MatchScorecard({ match }) {
  const scorecard = match.scorecard || {};
  return <div className="match-scorecard">
    <div className="match-scorecard__title"><div><span>OFFICIAL SCORECARD</span><h3>Full Match Record</h3></div><small>{match.format || 'T20'} · {match.ballType || 'White Ball'}</small></div>
    <BattingTable team={match.teamA?.name || 'Team A'} players={scorecard.teamA?.batting} />
    <div className="match-scorecard__extras">Extras <strong>{scorecard.teamA?.extras ?? match.teamA?.extras ?? '—'}</strong></div>
    <BattingTable team={match.teamB?.name || 'Team B'} players={scorecard.teamB?.batting} />
    <div className="match-scorecard__extras">Extras <strong>{scorecard.teamB?.extras ?? match.teamB?.extras ?? '—'}</strong></div>
    <BowlingTable team={match.teamB?.name || 'Team B'} bowlers={scorecard.teamB?.bowling || scorecard.bowlingA} />
    <BowlingTable team={match.teamA?.name || 'Team A'} bowlers={scorecard.teamA?.bowling || scorecard.bowlingB} />
    <div className="match-scorecard__fow"><b>Fall of Wickets</b><span>{scorecard.fallOfWickets || match.fallOfWickets || 'Recorded automatically from wicket events'}</span></div>
  </div>;
}
