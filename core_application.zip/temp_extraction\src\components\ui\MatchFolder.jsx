import React, { useState } from 'react';
import { ChevronDown, ChevronRight, FileText, Info, Trophy, Newspaper, Radio } from 'lucide-react';
import { MatchStatusBadge } from './Badge';

export default function MatchFolder({ match, onOpen }) {
  const [open, setOpen] = useState(false);
  const live = match.status === 'LIVE' || match.status === 'IN_PROGRESS';
  const completed = match.status === 'COMPLETED' || match.status === 'FINISHED';
  const teamA = match.teamA?.name || match.teamA || 'Jabalpur XI';
  const teamB = match.teamB?.name || match.teamB || 'Katni XI';
  const scoreA = match.teamA?.score || '—';
  const scoreB = match.teamB?.score || '—';

  return (
    <section className={`match-folder ${live ? 'match-folder--live' : ''}`}>
      <button className="match-folder__head" onClick={() => setOpen(v => !v)} aria-expanded={open}>
        <span className="match-folder__rail" />
        <span className="match-folder__badge">{live ? <Radio size={16} /> : <FileText size={16} />}</span>
        <span className="match-folder__main">
          <span className="match-folder__eyebrow">{match.matchNumber || 'MATCH'} · {match.format || match.category || 'T20'} · {match.date || 'Fixture'}</span>
          <span className="match-folder__teams"><strong>{teamA}</strong><span>vs</span><strong>{teamB}</strong></span>
          <span className="match-folder__meta">{match.venue || 'JDCA Ground'} · {match.stage || match.tournament || 'Association Fixture'}</span>
        </span>
        <span className="match-folder__scores"><b>{scoreA}</b><b>{scoreB}</b></span>
        <span className="match-folder__right"><MatchStatusBadge status={match.status} />{open ? <ChevronDown size={18}/> : <ChevronRight size={18}/>}</span>
      </button>

      {open && (
        <div className="match-folder__contents">
          <button onClick={() => onOpen?.(match, 'information')}><Info size={16}/> Match Information <ChevronRight size={15}/></button>
          <button onClick={() => onOpen?.(match, 'scorecard')}><FileText size={16}/> Full Scorecard <ChevronRight size={15}/></button>
          <button onClick={() => onOpen?.(match, 'highlights')}><Trophy size={16}/> Match Highlights <ChevronRight size={15}/></button>
          {completed && <button onClick={() => onOpen?.(match, 'media')}><Newspaper size={16}/> Media Report <ChevronRight size={15}/></button>}
          {live && <button className="match-folder__live-action" onClick={() => onOpen?.(match, 'live')}><Radio size={16}/> Open Live Scoring <ChevronRight size={15}/></button>}
        </div>
      )}
    </section>
  );
}
