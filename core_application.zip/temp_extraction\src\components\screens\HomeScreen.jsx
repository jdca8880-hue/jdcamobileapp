import React from 'react';
import {
  Users, Trophy, MapPin, Radio, Calendar, Plus,
  TrendingUp, ArrowRight, Megaphone
} from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { MatchStatusBadge } from '../ui/Badge';
import { PageHeader, SectionLabel } from '../ui/PageHeader';

const JDCA_DISTRICTS = [
  'Jabalpur','Katni','Narsinghpur','Seoni','Mandla','Balaghat','Chhindwara','Dindori','Pandhurna'
];

export default function HomeScreen() {
  const {
    matches, players, tournaments, districtStats, announcements,
    navigateTo, setActiveMatchId, userRole, userEmail
  } = useCricket();

  const liveMatches     = matches.filter(m => m.status === 'LIVE' || m.status === 'IN_PROGRESS');
  const upcomingMatches = matches.filter(m => m.status === 'UPCOMING' || m.status === 'SCHEDULED').slice(0, 3);
  const recentMatches   = matches.filter(m => m.status === 'COMPLETED' || m.status === 'FINISHED').slice(0, 3);
  const totalPlayers    = players.length;
  const activeTournaments = (tournaments || []).filter(t => t.status === 'ONGOING').length;

  const quickActions = [
    { label: 'Create Match',       icon: Plus,      action: () => navigateTo('match-setup'),           color: '#2457D6', bg: '#eef2fd' },
    { label: 'Start Live Scoring', icon: Radio,      action: () => navigateTo('scoring'),               color: '#0FA968', bg: '#e8f8ef' },
    { label: 'Add Player',         icon: Users,      action: () => navigateTo('player-registration'),   color: '#F4B942', bg: '#fef9ea' },
    { label: 'Create Tournament',  icon: Trophy,     action: () => navigateTo('tournaments'),           color: '#F05A47', bg: '#fef0ee' },
  ];

  const userName = userEmail ? userEmail.split('@')[0] : 'Official';
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

  return (
    <div className="fade-in-up" style={{ padding: '24px 20px 100px', maxWidth: 900, margin: '0 auto' }}>

      {/* Welcome greeting */}
      <div className="mb-6">
        <p style={{ fontSize: 13, color: '#596579', fontWeight: 500, marginBottom: 2 }}>
          {greeting}, {userName} 👋
        </p>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: '#101827', letterSpacing: '-0.02em', lineHeight: 1.2 }}>
          JDCA Dashboard
        </h1>
        <p style={{ fontSize: 13, color: '#596579', marginTop: 4 }}>
          Jabalpur District Cricket Association — Season 2026
        </p>
      </div>

      {/* ── Live Matches ───────────────────────────────── */}
      {liveMatches.length > 0 && (
        <div className="mb-6">
          <SectionLabel>
            <span className="flex items-center gap-1.5">
              <span className="live-dot" />
              Live Now
            </span>
          </SectionLabel>
          <div className="space-y-3">
            {liveMatches.map(match => (
              <div
                key={match.id}
                className="jdca-card-hover p-4 cursor-pointer"
                style={{ borderLeft: '3px solid #0FA968' }}
                onClick={() => { setActiveMatchId(match.id); navigateTo('scoring'); }}
              >
                <div className="flex items-center justify-between mb-3">
                  <span style={{ fontSize: 11, fontWeight: 600, color: '#596579', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    {match.tournament || 'JDCA Tournament'} · {match.format || 'T20'}
                  </span>
                  <MatchStatusBadge status="LIVE" />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div style={{ fontSize: 17, fontWeight: 800, color: '#101827', letterSpacing: '-0.01em' }}>
                      {match.teamA?.name || match.teamA || 'Team A'}
                    </div>
                    <div className="score-lg" style={{ color: '#2457D6', marginTop: 2 }}>
                      {match.teamA?.score || '142/4'}
                      <span style={{ fontSize: 14, fontWeight: 600, color: '#596579', marginLeft: 6 }}>
                        ({match.teamA?.overs || '18.2'} ov)
                      </span>
                    </div>
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#596579', textTransform: 'uppercase', letterSpacing: '0.1em' }}>vs</span>
                  <div className="text-right">
                    <div style={{ fontSize: 17, fontWeight: 800, color: '#101827', letterSpacing: '-0.01em' }}>
                      {match.teamB?.name || match.teamB || 'Team B'}
                    </div>
                    <div style={{ fontSize: 13, color: '#596579', marginTop: 2 }}>Yet to bat</div>
                  </div>
                </div>
                <div
                  className="flex items-center justify-between mt-3 pt-3"
                  style={{ borderTop: '1px solid #f0f2f4' }}
                >
                  <div className="flex items-center gap-1" style={{ fontSize: 12, color: '#596579' }}>
                    <MapPin size={12} strokeWidth={2} />
                    <span>{match.venue || 'Jabalpur Cricket Ground'}</span>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#2457D6', display: 'flex', alignItems: 'center', gap: 4 }}>
                    Score Match <ArrowRight size={13} strokeWidth={2.5} />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Stats strip ──────────────────────────────── */}
      <div className="mb-6" style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10 }}>
        {[
          { value: totalPlayers, label: 'Total Players',       color: '#2457D6', bg: '#eef2fd' },
          { value: activeTournaments || 3, label: 'Tournaments', color: '#0FA968', bg: '#e8f8ef' },
          { value: JDCA_DISTRICTS.length, label: 'Districts',   color: '#F4B942', bg: '#fef9ea' },
          { value: liveMatches.length, label: 'Live Now',       color: '#F05A47', bg: '#fef0ee' },
        ].map((s, i) => (
          <div
            key={i}
            className="jdca-card p-3"
            style={{ background: s.bg, border: `1px solid ${s.bg}` }}
          >
            <div style={{ fontSize: 24, fontWeight: 800, color: s.color, lineHeight: 1 }} className="font-tabular">
              {s.value}
            </div>
            <div style={{ fontSize: 11, color: '#596579', marginTop: 4, fontWeight: 500 }}>
              {s.label}
            </div>
          </div>
        ))}
      </div>

      {/* ── Quick Actions ──────────────────────────── */}
      <div className="mb-6">
        <SectionLabel>Quick Actions</SectionLabel>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 10 }}>
          {quickActions.map((a, i) => {
            const Icon = a.icon;
            return (
              <button
                key={i}
                id={`home-quick-action-${i}`}
                onClick={a.action}
                className="jdca-card-hover p-4 flex items-center gap-3 cursor-pointer text-left"
                style={{ border: 'none' }}
              >
                <div
                  className="flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0"
                  style={{ background: a.bg }}
                >
                  <Icon size={18} style={{ color: a.color }} strokeWidth={2.2} />
                </div>
                <span style={{ fontSize: 14, fontWeight: 600, color: '#101827' }}>
                  {a.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Upcoming Matches ──────────────────────── */}
      {upcomingMatches.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <SectionLabel className="mb-0">Upcoming Matches</SectionLabel>
            <button
              onClick={() => navigateTo('matches')}
              style={{ fontSize: 12, fontWeight: 600, color: '#2457D6', background: 'none', border: 'none', cursor: 'pointer' }}
            >
              View all
            </button>
          </div>
          <div className="space-y-2">
            {upcomingMatches.map((m, i) => (
              <div key={i} className="jdca-card p-3 flex items-center justify-between">
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: '#101827' }}>
                    {m.teamA?.name || m.teamA || 'Team A'} vs {m.teamB?.name || m.teamB || 'Team B'}
                  </div>
                  <div className="flex items-center gap-3 mt-1">
                    <span style={{ fontSize: 11, color: '#596579' }}>{m.date || '12 Sep 2026'}</span>
                    <span style={{ fontSize: 11, color: '#596579' }}>
                      <MapPin size={10} strokeWidth={2} style={{ display: 'inline', marginRight: 2 }} />
                      {m.venue || 'Jabalpur Ground'}
                    </span>
                  </div>
                </div>
                <MatchStatusBadge status="UPCOMING" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Recent Results ──────────────────────── */}
      {recentMatches.length > 0 && (
        <div className="mb-6">
          <SectionLabel>Recent Results</SectionLabel>
          <div className="space-y-2">
            {recentMatches.map((m, i) => (
              <div
                key={i}
                className="jdca-card-hover p-3 cursor-pointer"
                onClick={() => navigateTo('match-result')}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span style={{ fontSize: 11, fontWeight: 600, color: '#596579', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    {m.tournament || 'JDCA T20 Trophy'}
                  </span>
                  <MatchStatusBadge status="COMPLETED" />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: '#101827' }}>
                      {m.teamA?.name || m.teamA || 'Jabalpur XI'}
                      <span style={{ fontSize: 15, fontWeight: 800, color: '#101827', marginLeft: 8 }}>
                        {m.teamA?.score || '178/7'}
                      </span>
                    </div>
                    <div style={{ fontSize: 12, color: '#596579', marginTop: 2 }}>
                      {m.teamB?.name || m.teamB || 'Katni XI'}
                      <span style={{ marginLeft: 8, color: '#596579', fontWeight: 600 }}>
                        {m.teamB?.score || '165/9'}
                      </span>
                    </div>
                  </div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#2457D6', textAlign: 'right', maxWidth: 120 }}>
                    {m.result || 'Jabalpur won by 13 runs'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Announcements ──────────────────────── */}
      {announcements && announcements.length > 0 && (
        <div>
          <SectionLabel className="flex items-center gap-1.5">
            <Megaphone size={12} strokeWidth={2} />
            Notices & Announcements
          </SectionLabel>
          <div className="space-y-2">
            {announcements.slice(0, 3).map((ann) => (
              <div
                key={ann.id}
                className="jdca-card p-3 flex items-start gap-3"
              >
                <span style={{ fontSize: 20 }}>{ann.icon}</span>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#101827' }}>{ann.title}</div>
                  <div style={{ fontSize: 12, color: '#596579', marginTop: 2 }}>{ann.body}</div>
                  <div style={{ fontSize: 11, color: '#8a99b0', marginTop: 4 }}>
                    {new Date(ann.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
