import React from 'react';
import {
  ArrowLeft, Bell, Search, LogOut
} from 'lucide-react';
import { useCricket } from '../context/CricketContext';
import { RoleBadge } from './ui/Badge';

// Screen-level titles
const SCREEN_TITLES = {
  'home':              { title: 'JDCA',                 showBack: false },
  'matches':           { title: 'Matches',              showBack: false },
  'match-setup':       { title: 'Match Setup',          showBack: true },
  'scoring':           { title: 'Live Score',         showBack: true },
  'scorecard':         { title: 'Scorecard',            showBack: true },
  'match-overview':    { title: 'Match Overview',       showBack: true },
  'innings-break':     { title: 'Innings Break',        showBack: true },
  'match-result':      { title: 'Match Result',         showBack: true },
  'tournaments':       { title: 'Tournaments',          showBack: false },
  'players':           { title: 'Players',              showBack: false },
  'scouting':          { title: 'Players',              showBack: false },
  'player-profile':    { title: 'Player Profile',       showBack: true },
  'player-registration':{ title: 'Add Player',          showBack: true },
  'selection':         { title: 'Player Selection',            showBack: false },
  'selectors':         { title: 'Player Selection',            showBack: false },
  'administration':    { title: 'Administration',       showBack: false },
  'access-control':    { title: 'Administration',       showBack: false },
};

export default function Header() {
  const { currentScreen, goBack, userRole, userEmail, navigateTo } = useCricket();

  if (currentScreen === 'welcome') return null;

  const info = SCREEN_TITLES[currentScreen] || { title: 'JDCA', showBack: false };

  return (
    <header
      className="lg:hidden sticky top-0 z-30 flex items-center justify-between px-4"
      style={{
        height: 56,
        background: '#101827',
        borderBottom: '1px solid rgba(255,255,255,0.07)',
      }}
    >
      {/* Left: back button or JDCA wordmark */}
      <div className="flex items-center gap-2">
        {info.showBack ? (
          <button
            onClick={goBack}
            className="flex items-center justify-center w-8 h-8 rounded-lg cursor-pointer"
            style={{ background: 'rgba(255,255,255,0.1)', border: 'none' }}
            aria-label="Back"
            id="header-back-btn"
          >
            <ArrowLeft size={18} style={{ color: '#ffffff' }} strokeWidth={2.5} />
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <div
              className="flex items-center justify-center w-7 h-7 rounded-md"
              style={{ background: '#2457D6', fontSize: 11, fontWeight: 800, color: '#fff' }}
            >
              JD
            </div>
          </div>
        )}
        <span
          className="font-bold"
          style={{ color: '#ffffff', fontSize: 17, letterSpacing: '-0.01em' }}
        >
          {info.title}
        </span>
      </div>

      {/* Right: role badge + search */}
      <div className="flex items-center gap-2">
        <span
          className="hidden sm:inline-block text-xs font-semibold px-2 py-0.5 rounded"
          style={{ background: 'rgba(255,255,255,0.1)', color: '#8a99b0' }}
        >
          {userRole}
        </span>
        <button
          onClick={() => navigateTo('players')}
          className="flex items-center justify-center w-8 h-8 rounded-lg cursor-pointer"
          style={{ background: 'rgba(255,255,255,0.08)', border: 'none' }}
          aria-label="Search players"
          id="header-search-btn"
        >
          <Search size={17} style={{ color: '#8a99b0' }} strokeWidth={2} />
        </button>
      </div>
    </header>
  );
}
