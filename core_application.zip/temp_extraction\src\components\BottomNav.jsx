import React from 'react';
import { useCricket } from '../context/CricketContext';
import {
  Home, Calendar, Radio, Users, MoreHorizontal
} from 'lucide-react';

const PRIMARY_TABS = [
  { id: 'home',    label: 'Home',        icon: Home,     route: 'home' },
  { id: 'matches', label: 'Matches',     icon: Calendar, route: 'matches' },
  { id: 'scoring', label: 'Live Score',        icon: Radio,    route: 'scoring', liveIndicator: true },
  { id: 'players', label: 'Players',     icon: Users,    route: 'players' },
  { id: 'more',    label: 'More',        icon: MoreHorizontal, route: null },
];

const ACTIVE_MAP = {
  'home': 'home',
  'matches': 'matches', 'match-setup': 'matches', 'match-overview': 'matches',
  'match-result': 'matches', 'innings-break': 'matches',
  'scoring': 'scoring', 'scorecard': 'scoring',
  'players': 'players', 'scouting': 'players', 'player-profile': 'players',
  'player-registration': 'players',
  'tournaments': 'more', 'selection': 'more', 'selectors': 'more',
  'administration': 'more', 'access-control': 'more',
};

export default function BottomNav() {
  const {
    currentScreen,
    navigateTo,
    userRole,
    drawerOpen,
    setDrawerOpen
  } = useCricket();

  if (currentScreen === 'welcome') return null;

  const activeId = ACTIVE_MAP[currentScreen] || 'home';

  const tabs = PRIMARY_TABS.filter(tab => {
    if (userRole === 'Scorer')   return ['home','matches','scoring','more'].includes(tab.id);
    if (userRole === 'Selector') return ['home','players','more'].includes(tab.id);
    if (userRole === 'Player')   return ['home','matches','players','more'].includes(tab.id);
    return true;
  });

  return (
    <nav
      className="lg:hidden sticky bottom-0 z-40"
      style={{
        background: '#ffffff',
        borderTop: '1px solid #e5e8ec',
        boxShadow: '0 -2px 12px rgba(0,0,0,0.06)',
      }}
    >
      <div className="flex items-stretch justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeId === tab.id;
          const isMore = tab.id === 'more';

          const handleClick = () => {
            if (isMore) {
              setDrawerOpen(true);
            } else {
              navigateTo(tab.route);
            }
          };

          return (
            <button
              key={tab.id}
              id={`bottom-nav-${tab.id}`}
              onClick={handleClick}
              className="flex flex-col items-center justify-center py-2 flex-1 gap-0.5 cursor-pointer"
              style={{
                minWidth: 0,
                border: 'none',
                background: 'none',
                paddingTop: 10,
                paddingBottom: 10,
              }}
            >
              <div className="relative">
                <Icon
                  size={22}
                  strokeWidth={isActive ? 2.5 : 2}
                  style={{ color: isActive ? '#2457D6' : '#8a99b0' }}
                />
                {tab.liveIndicator && (
                  <span
                    className="absolute -top-0.5 -right-0.5 live-dot"
                    style={{ width: 7, height: 7 }}
                  />
                )}
              </div>
              <span
                style={{
                  fontSize: 10,
                  fontWeight: isActive ? 700 : 500,
                  color: isActive ? '#2457D6' : '#8a99b0',
                  lineHeight: 1,
                  marginTop: 2,
                }}
              >
                {tab.label}
              </span>
              {isActive && (
                <span
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    width: 20,
                    height: 2,
                    background: '#2457D6',
                    borderRadius: 2,
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
