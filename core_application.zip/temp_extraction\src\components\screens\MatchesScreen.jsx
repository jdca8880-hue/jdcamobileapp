import React, { useMemo, useState } from 'react';
import { Plus, Search, ChevronDown, ChevronRight, CalendarDays, FolderOpen } from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { PageHeader, TabBar } from '../ui/PageHeader';
import MatchFolder from '../ui/MatchFolder';

const TABS = [
  { id: 'all', label: 'All Matches' },
  { id: 'live', label: 'Live' },
  { id: 'upcoming', label: 'Upcoming' },
  { id: 'completed', label: 'Completed' },
];

export default function MatchesScreen() {
  const { matches = [], navigateTo, setActiveMatchId } = useCricket();
  const [activeTab, setActiveTab] = useState('all');
  const [search, setSearch] = useState('');
  const [openTournaments, setOpenTournaments] = useState({});

  const filtered = useMemo(() => matches.filter(m => {
    const status = String(m.status || '').toUpperCase();
    const live = status === 'LIVE' || status === 'IN_PROGRESS';
    const upcoming = status === 'UPCOMING' || status === 'SCHEDULED';
    const completed = status === 'COMPLETED' || status === 'FINISHED';
    const haystack = `${m.tournament || ''} ${m.venue || ''} ${m.teamA?.name || m.teamA || ''} ${m.teamB?.name || m.teamB || ''}`.toLowerCase();
    if (!haystack.includes(search.toLowerCase())) return false;
    if (activeTab === 'live') return live;
    if (activeTab === 'upcoming') return upcoming;
    if (activeTab === 'completed') return completed;
    return true;
  }), [matches, activeTab, search]);

  const groups = useMemo(() => {
    const map = new Map();
    filtered.forEach(m => {
      const name = m.tournament || 'JDCA Official Fixtures';
      if (!map.has(name)) map.set(name, []);
      map.get(name).push(m);
    });
    return [...map.entries()];
  }, [filtered]);

  const openMatch = (match, section) => {
    setActiveMatchId(match.id);
    if (section === 'live') navigateTo('scoring');
    else navigateTo('match-detail');
  };

  return <div className="matches-directory-page">
    <PageHeader title="Matches Directory" subtitle="Every sanctioned fixture becomes a complete digital match folder" action={<button className="btn-primary" onClick={() => navigateTo('match-setup')}><Plus size={16}/> Create Match</button>} />

    <div className="matches-toolbar">
      <div className="matches-search"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search team, tournament or venue"/></div>
      <TabBar tabs={TABS} active={activeTab} onChange={setActiveTab}/>
    </div>

    <div className="matches-directory-intro"><FolderOpen size={18}/><div><strong>Digital Match Directory</strong><span>Open a tournament, then open any match to see its information, scorecard, highlights and media report.</span></div><b>{filtered.length} matches</b></div>

    <div className="match-directory-tree">
      {groups.map(([tournament, tournamentMatches], index) => {
        const isOpen = openTournaments[tournament] ?? true;
        return <section className="tournament-folder" key={tournament}>
          <button className="tournament-folder__header" onClick={() => setOpenTournaments(s => ({...s, [tournament]: !isOpen}))}>
            <span className="tournament-folder__icon"><FolderOpen size={18}/></span>
            <span><small>TOURNAMENT FOLDER {String(index + 1).padStart(2,'0')}</small><strong>{tournament}</strong><em>{tournamentMatches.length} fixture{tournamentMatches.length !== 1 ? 's' : ''}</em></span>
            {isOpen ? <ChevronDown size={18}/> : <ChevronRight size={18}/>} 
          </button>
          {isOpen && <div className="tournament-folder__body">{tournamentMatches.map(match => <MatchFolder key={match.id} match={match} onOpen={openMatch}/>)}</div>}
        </section>;
      })}
    </div>

    {!filtered.length && <div className="directory-empty"><CalendarDays size={30}/><strong>No matches found</strong><span>Try another search or switch the match status filter.</span></div>}
  </div>;
}
