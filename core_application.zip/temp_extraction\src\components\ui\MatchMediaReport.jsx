import React, { useMemo, useState } from 'react';
import { Copy, Share2, Printer, Check, MessageCircle, Download } from 'lucide-react';
import { calculateMatchHighlights, generateMatchSummary, generateSocialCaption } from '../../engine/matchSummaryEngine';

export default function MatchMediaReport({ match }) {
  const [copied, setCopied] = useState(false);
  const highlights = useMemo(() => calculateMatchHighlights(match), [match]);
  const summary = useMemo(() => generateMatchSummary(match, highlights), [match, highlights]);
  const caption = useMemo(() => generateSocialCaption(match, highlights), [match, highlights]);
  const headline = match.mediaHeadline || `${match.teamA?.name || 'Team A'} vs ${match.teamB?.name || 'Team B'} — Official Match Report`;

  const copy = async (text = summary) => {
    try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch {}
  };

  return <div className="match-media-report">
    <div className="match-media-report__masthead"><div><strong>JABALPUR DISTRICT CRICKET ASSOCIATION</strong><span>OFFICIAL MATCH COMMUNICATION</span></div><span>{match.date || 'Match Day'}</span></div>
    <div className="match-media-report__body">
      <span className="match-media-report__kicker">MATCH REPORT · {match.stage || match.tournament || 'JDCA FIXTURE'}</span>
      <h2>{headline}</h2>
      <p className="match-media-report__standfirst">{summary}</p>
      <div className="match-media-report__scoreline"><div><span>{match.teamA?.name}</span><b>{match.teamA?.score || '—'}</b></div><i>VS</i><div><span>{match.teamB?.name}</span><b>{match.teamB?.score || '—'}</b></div></div>
      <div className="match-media-report__facts">
        <div><small>RESULT</small><b>{match.resultText || match.result || 'Official result pending'}</b></div>
        <div><small>VENUE</small><b>{match.venue || 'JDCA Ground'}</b></div>
        <div><small>TOP BATTER</small><b>{highlights.topBatter?.name || '—'} {highlights.topBatter?.stat ? `· ${highlights.topBatter.stat}` : ''}</b></div>
        <div><small>TOP BOWLER</small><b>{highlights.topBowler?.name || '—'} {highlights.topBowler?.stat ? `· ${highlights.topBowler.stat}` : ''}</b></div>
        <div><small>PLAYER OF THE MATCH</small><b>{highlights.playerOfMatch?.name || 'Official selection'}</b></div>
        <div><small>FORMAT</small><b>{match.format || '—'} · {match.ballType || '—'}</b></div>
      </div>
      <div className="match-media-report__caption"><small>SOCIAL / WHATSAPP VERSION</small><pre>{caption}</pre></div>
    </div>
    <div className="match-media-report__actions">
      <button onClick={() => copy()}>{copied ? <Check size={16}/> : <Copy size={16}/>} {copied ? 'Copied' : 'Copy Report'}</button>
      <button onClick={() => copy(caption)}><MessageCircle size={16}/> Copy Social</button>
      <button onClick={() => navigator.share ? navigator.share({title: headline, text: summary}) : copy(summary)}><Share2 size={16}/> Share</button>
      <button onClick={() => window.print()}><Printer size={16}/> Print</button>
      <button onClick={() => copy(summary)}><Download size={16}/> Export Text</button>
    </div>
  </div>;
}
