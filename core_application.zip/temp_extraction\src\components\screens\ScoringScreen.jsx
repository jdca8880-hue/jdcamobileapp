import React, { useEffect, useMemo, useState } from 'react';
import {
  RotateCcw, FileText, ShieldAlert, AlertTriangle, X, Check,
  Users, ChevronRight, RefreshCw, Radio, CircleHelp, WifiOff,
  MoreHorizontal
} from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { FREE_HIT_ALLOWED_DISMISSALS } from '../../engine/validationSchemas';

const DISMISSALS = ['Bowled', 'Caught', 'LBW', 'Run Out', 'Stumped', 'Hit Wicket', 'Other'];
const QUICK_RUNS = [0, 1, 2, 3, 4, 6];

function Modal({ title, children, onClose, danger = false }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#101827]/65 p-3 sm:p-5">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className={`px-5 py-4 border-b flex items-center justify-between ${danger ? 'border-coral-100' : 'border-slate-100'}`}>
          <h3 className="text-base font-extrabold text-ink">{title}</h3>
          <button onClick={onClose} className="w-9 h-9 rounded-lg hover:bg-slate-100 flex items-center justify-center" aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export default function ScoringScreen() {
  const {
    runs, wickets, balls, formatOvers, calculateCRR, calculateProjectedScore,
    currentOverBalls, striker, nonStriker, currentBowler, isFreeHit, toggleStriker,
    validationError, setValidationError, matchStatus, recordRuns, recordExtra,
    recordWicket, undoLastAction, innings, navigateTo, activeMatchId, matches,
    matchSetup, replaceStriker, continueAfterOver, lastOverBowlerId,
    deliveryLog = [], scoringFirstRunDone, markScoringFirstRunDone,
  } = useCricket();

  const [dismissalOpen, setDismissalOpen] = useState(false);
  const [selectedDismissal, setSelectedDismissal] = useState('Caught');
  const [fielder, setFielder] = useState('');
  const [newBatterOpen, setNewBatterOpen] = useState(false);
  const [overOpen, setOverOpen] = useState(false);
  const [extrasOpen, setExtrasOpen] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [practiceStep, setPracticeStep] = useState(0);

  const activeMatch = matches?.find(m => m.id === activeMatchId);
  const teamAName = activeMatch?.teamA?.name || activeMatch?.teamA || 'Jabalpur District XI';
  const teamBName = activeMatch?.teamB?.name || activeMatch?.teamB || 'Mandla District XI';
  const tournamentName = activeMatch?.tournament || 'JDCA District Cricket';
  const playingXI = matchSetup?.playingXI || [];

  const batters = useMemo(() => playingXI.filter(p => p?.name && p.name !== striker?.name && p.name !== nonStriker?.name), [playingXI, striker?.name, nonStriker?.name]);
  const lastBalls = deliveryLog.length ? deliveryLog.slice(-6) : currentOverBalls.map((b, i) => ({ ...b, id: `mock-${i}`, runs: Number(b.value) || 0, wicket: b.type === 'wicket', extra: b.type === 'extra' }));
  const isOverComplete = matchStatus === 'OVER_COMPLETE';

  useEffect(() => {
    if (isOverComplete) setOverOpen(true);
  }, [isOverComplete]);

  const doRun = (value) => {
    recordRuns(value);
    if (!scoringFirstRunDone) markScoringFirstRunDone?.();
  };

  const submitWicket = () => {
    recordWicket(selectedDismissal, striker.name, fielder);
    setDismissalOpen(false);
    setFielder('');
    setNewBatterOpen(true);
  };

  const selectNewBatter = (player) => {
    if (player) replaceStriker?.({ ...player, runs: 0, balls: 0, fours: 0, sixes: 0, strikeRate: '0.0' });
    setNewBatterOpen(false);
  };

  const selectNextBowler = (player) => {
    if (!player) return;
    if (lastOverBowlerId && player.id === lastOverBowlerId) {
      setValidationError('The same bowler cannot bowl two consecutive overs.');
      return;
    }
    continueAfterOver?.(player);
    setOverOpen(false);
  };

  const practiceActions = [
    { label: 'Tap 1 run', hint: 'The score and striker update automatically.' },
    { label: 'Tap a dot ball', hint: 'The ball is counted, but no run is added.' },
    { label: 'Tap 4 runs', hint: 'The batter gets the runs and the boundary is recorded.' },
    { label: 'Tap Wide', hint: 'The extra is recorded and the ball does not count as legal.' },
  ];
  return (
    <div className="scorer-page fade-in-up">
      {validationError && (
        <div className="scorer-alert">
          <AlertTriangle size={18} />
          <span>{validationError}</span>
          <button onClick={() => setValidationError(null)}><X size={16} /></button>
        </div>
      )}

      <div className="scorer-topbar">
        <div>
          <div className="scorer-kicker">{tournamentName}</div>
          <div className="scorer-match-title">{teamAName} <span>vs</span> {teamBName}</div>
        </div>
        <div className="scorer-top-actions">
          <span className="live-chip"><span className="live-dot" /> LIVE</span>
          <button className="icon-action" onClick={() => setShowHelp(true)} title="Scoring help"><CircleHelp size={18} /></button>
          <button className="icon-action" onClick={() => navigateTo('scorecard')} title="Scorecard"><FileText size={18} /></button>
        </div>
      </div>

      {!scoringFirstRunDone && (
        <div className="learn-strip">
          <div className="learn-copy">
            <strong>New to JDCA scoring?</strong>
            <span>Learn the four basic taps in under 2 minutes.</span>
          </div>
          <button className="btn-primary" onClick={() => setShowHelp(true)}>Learn Scoring</button>
        </div>
      )}

      {isFreeHit && (
        <div className="free-hit-strip"><strong>FREE HIT</strong><span>Run Out / allowed dismissals only</span></div>
      )}

      <section className="score-console">
        <div className="score-console-head">
          <div>
            <span className="innings-label">{innings === 1 ? '1st Innings' : '2nd Innings'} · {innings === 1 ? teamAName : teamBName}</span>
            <div className="score-line"><strong>{runs}</strong><span>/{wickets}</span></div>
          </div>
          <div className="overs-block"><span>Overs</span><strong>{formatOvers(balls)}</strong></div>
        </div>

        <div className="metric-row">
          <div><span>CRR</span><strong>{calculateCRR()}</strong></div>
          <div><span>Projected</span><strong>{calculateProjectedScore(runs, balls, totalOversSafe(matchSetup?.totalOvers))}</strong></div>
          <div><span>Remaining</span><strong>{Math.max(0, (matchSetup?.totalOvers || 20) * 6 - balls)} balls</strong></div>
        </div>

        <div className="players-row">
          <button className="crease-player striker" onClick={() => toggleStriker?.()}>
            <div><span className="player-role">STRIKER *</span><strong>{striker.name}</strong></div>
            <span className="player-stat">{striker.runs} <small>({striker.balls})</small></span>
          </button>
          <button className="crease-player" onClick={() => toggleStriker?.()}>
            <div><span className="player-role">NON-STRIKER</span><strong>{nonStriker.name}</strong></div>
            <span className="player-stat">{nonStriker.runs} <small>({nonStriker.balls})</small></span>
          </button>
        </div>

        <div className="bowler-row">
          <div><span>Bowler</span><strong>{currentBowler.name}</strong></div>
          <div className="bowler-figures">{currentBowler.overs}-{currentBowler.maidens}-{currentBowler.runs}-{currentBowler.wickets}</div>
        </div>

        <div className="recent-balls">
          <div className="recent-head"><span>Last balls</span><span>{currentOverBalls.length} legal balls in over</span></div>
          <div className="ball-track">
            {lastBalls.map((b, i) => <span key={i} className={`ball-chip ${b.wicket ? 'wicket' : b.extra ? 'extra' : b.runs >= 4 ? 'boundary' : ''}`}>{b.label || b.runs || 0}</span>)}
            {!lastBalls.length && <span className="empty-balls">No balls recorded yet</span>}
          </div>
        </div>
      </section>

      <section className="scoring-pad">
        <div className="pad-head">
          <div><span className="section-label">What happened?</span><strong>Tap the result of this ball</strong></div>
          <button className="undo-button" onClick={undoLastAction} disabled={!deliveryLog.length}><RotateCcw size={16} /> Undo</button>
        </div>

        <div className="run-grid">
          {QUICK_RUNS.map(value => (
            <button key={value} onClick={() => doRun(value)} className={`run-key ${value >= 4 ? 'boundary-key' : ''}`} aria-label={`${value} runs`}>{value}</button>
          ))}
        </div>

        <div className="event-grid">
          <button className="event-key wicket-key" onClick={() => setDismissalOpen(true)}><ShieldAlert size={20} /> WICKET</button>
          <button className="event-key extra-key" onClick={() => recordExtra('wide', 0)}>WIDE</button>
          <button className="event-key extra-key" onClick={() => recordExtra('no_ball', 0)}>NO BALL</button>
          <button className="event-key soft-key" onClick={() => recordExtra('bye', 1)}>BYE</button>
          <button className="event-key soft-key" onClick={() => recordExtra('leg_bye', 1)}>LEG BYE</button>
          <button className="event-key more-key" onClick={() => setExtrasOpen(true)}><MoreHorizontal size={18} /> MORE</button>
        </div>

        <div className="scorer-note"><WifiOff size={14} /> Score entries are designed to keep working if the connection drops.</div>
      </section>

      <section className="scorer-tools">
        <button onClick={() => setOverOpen(true)}><RefreshCw size={16} /> Change Bowler</button>
        <button onClick={() => navigateTo('scorecard')}><FileText size={16} /> Scorecard</button>
        <button onClick={() => navigateTo('innings-break')}><ChevronRight size={16} /> End Innings</button>
      </section>

      {dismissalOpen && (
        <Modal title="Record Wicket" danger onClose={() => setDismissalOpen(false)}>
          <div className="modal-context"><span>{striker.name}</span><strong>is out</strong></div>
          <div className="modal-section-title">How out?</div>
          <div className="choice-grid">
            {DISMISSALS.map(type => {
              const blocked = isFreeHit && !FREE_HIT_ALLOWED_DISMISSALS.includes(type);
              return <button key={type} disabled={blocked} className={selectedDismissal === type && !blocked ? 'selected' : ''} onClick={() => setSelectedDismissal(type)}>{type}</button>;
            })}
          </div>
          {(selectedDismissal === 'Caught' || selectedDismissal === 'Run Out' || selectedDismissal === 'Stumped') && (
            <div className="mt-4">
              <label className="modal-label">Fielder / Wicket Keeper (optional)</label>
              <select className="jdca-input" value={fielder} onChange={e => setFielder(e.target.value)}>
                <option value="">Select player</option>
                {playingXI.filter(p => p.name !== striker.name).map(p => <option key={p.id} value={p.name}>{p.name}</option>)}
              </select>
            </div>
          )}
          <div className="modal-actions"><button className="btn-secondary" onClick={() => setDismissalOpen(false)}>Cancel</button><button className="btn-danger" onClick={submitWicket}>Confirm Wicket</button></div>
        </Modal>
      )}

      {newBatterOpen && wickets < 10 && (
        <Modal title="New Batter" onClose={() => setNewBatterOpen(false)}>
          <p className="modal-hint">Select the next batter. Everything else has already been recorded.</p>
          <div className="player-choice-list">
            {batters.map(player => <button key={player.id} onClick={() => selectNewBatter(player)}><span>{player.name}</span><small>{player.role || 'Player'}</small><ChevronRight size={16} /></button>)}
            {!batters.length && <button onClick={() => setNewBatterOpen(false)}><span>Continue with next batter</span><ChevronRight size={16} /></button>}
          </div>
        </Modal>
      )}

      {overOpen && !newBatterOpen && (
        <Modal title="Over Complete" onClose={() => setOverOpen(false)}>
          <div className="over-summary"><strong>{runs}/{wickets}</strong><span>after {formatOvers(balls)} overs</span></div>
          <div className="modal-section-title">Select next bowler</div>
          <div className="player-choice-list">
            {playingXI.filter(p => /bowler|all-rounder/i.test(p.role || '') && p.id !== lastOverBowlerId).map(player => <button key={player.id} onClick={() => selectNextBowler(player)}><span>{player.name}</span><small>{player.role}</small><ChevronRight size={16} /></button>)}
          </div>
          <p className="modal-hint">The same bowler cannot bowl two overs in a row.</p>
        </Modal>
      )}

      {extrasOpen && (
        <Modal title="More Extras" onClose={() => setExtrasOpen(false)}>
          <p className="modal-hint">Use these only when the extra was more than the normal one run.</p>
          <div className="extra-options">
            {[2, 3, 4].map(value => <button key={`bye-${value}`} onClick={() => { recordExtra('bye', value); setExtrasOpen(false); }}>Bye {value}</button>)}
            {[2, 3, 4].map(value => <button key={`lb-${value}`} onClick={() => { recordExtra('leg_bye', value); setExtrasOpen(false); }}>Leg Bye {value}</button>)}
            <button onClick={() => { recordExtra('wide', 4); setExtrasOpen(false); }}>Wide + 4</button>
            <button onClick={() => { recordExtra('no_ball', 4); setExtrasOpen(false); }}>No Ball + 4</button>
          </div>
        </Modal>
      )}

      {showHelp && (
        <Modal title="Learn Live Scoring" onClose={() => setShowHelp(false)}>
          <div className="learn-modal">
            <div className="learn-progress"><span style={{ width: `${((practiceStep + 1) / practiceActions.length) * 100}%` }} /></div>
            <div className="learn-number">{practiceStep + 1}</div>
            <h4>{practiceActions[practiceStep].label}</h4>
            <div className="learn-demo-key">{practiceActions[practiceStep].label.replace('Tap ', '')}</div>
            <p>{practiceActions[practiceStep].hint} The scorer only taps what happened. JDCA calculates the score, balls, batter figures, bowler figures and extras automatically.</p>
            <button className="btn-primary w-full" onClick={() => { if (practiceStep === practiceActions.length - 1) { markScoringFirstRunDone?.(); setShowHelp(false); } else setPracticeStep(s => s + 1); }}>
              {practiceStep === practiceActions.length - 1 ? 'I’m Ready to Score' : 'Try It'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function totalOversSafe(value) {
  return Number(value) || 20;
}
