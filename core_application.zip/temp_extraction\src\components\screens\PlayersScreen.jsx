import React, { useState } from 'react';
import {
  Search, Filter, Plus, User, ArrowUpDown, ChevronRight,
  Shield, Award, MapPin, Eye, Star, Users, ChevronDown, ChevronUp
} from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { PageHeader, TabBar } from '../ui/PageHeader';
import { Badge } from '../ui/Badge';

const JDCA_DISTRICTS = [
  'All Districts',
  'Jabalpur',
  'Katni',
  'Narsinghpur',
  'Seoni',
  'Mandla',
  'Balaghat',
  'Chhindwara',
  'Dindori',
  'Pandhurna'
];

const AGE_CATEGORIES = [
  'All Categories',
  'Senior',
  'Under 22',
  'Under 18',
  'Under 15',
  'Under 13',
  "Women's Senior",
  "Women's Under 22",
  "Women's Under 18"
];

const ROLES = ['All Roles', 'Batter', 'Bowler', 'All-Rounder', 'Wicket Keeper'];

export default function PlayersScreen() {
  const {
    players,
    setSelectedPlayer,
    navigateTo,
    shortlistedIds,
    toggleShortlist
  } = useCricket();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('All Districts');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedRole, setSelectedRole] = useState('All Roles');
  const [viewMode, setViewMode] = useState('table'); // 'table' or 'grid'

  // Filter logic
  const filteredPlayers = players.filter((player) => {
    const matchesSearch =
      (player.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (player.team || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (player.district || '').toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDistrict =
      selectedDistrict === 'All Districts' ||
      (player.district || '').toLowerCase() === selectedDistrict.toLowerCase();

    const normalizeCat = (cat = '') => cat.replace(/[-_]/g, ' ').toLowerCase();
    const matchesCategory =
      selectedCategory === 'All Categories' ||
      normalizeCat(player.category).includes(normalizeCat(selectedCategory)) ||
      normalizeCat(selectedCategory).includes(normalizeCat(player.category));

    const matchesRole =
      selectedRole === 'All Roles' ||
      (player.role || '').toLowerCase() === selectedRole.toLowerCase();

    return matchesSearch && matchesDistrict && matchesCategory && matchesRole;
  });

  const handlePlayerClick = (player) => {
    setSelectedPlayer(player);
    navigateTo('player-profile');
  };

  const [openMobileDistricts, setOpenMobileDistricts] = useState({});
  const [openMobileAges, setOpenMobileAges] = useState({});

  const toggleMobileDistrict = (key) => {
    setOpenMobileDistricts((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleMobileAge = (key) => {
    setOpenMobileAges((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const mobileGroups = [
    {
      key: 'men',
      title: 'Men',
      subtitle: 'District players and age groups',
      players: filteredPlayers.filter((p) => !String(p.category || '').toLowerCase().includes('women')),
    },
    {
      key: 'women',
      title: 'Women',
      subtitle: 'District players and age groups',
      players: filteredPlayers.filter((p) => String(p.category || '').toLowerCase().includes('women')),
    },
  ].filter((group) => group.players.length > 0);

  const mobileAgeOrder = ['Under 13', 'Under 15', 'Under 18', 'Under 22', 'Senior'];

  const getMobileAge = (player) => {
    const raw = String(player.category || 'Senior');
    const normalized = raw.toLowerCase().replace(/[-_]/g, ' ');
    if (normalized.includes('under 13') || normalized.includes('u13')) return 'Under 13';
    if (normalized.includes('under 15') || normalized.includes('u15')) return 'Under 15';
    if (normalized.includes('under 18') || normalized.includes('u18')) return 'Under 18';
    if (normalized.includes('under 22') || normalized.includes('u22')) return 'Under 22';
    return 'Senior';
  };

  return (
    <div className="fade-in-up" style={{ padding: '24px 20px 100px', maxWidth: 1100, margin: '0 auto' }}>
      <PageHeader
        title="Player Management"
        subtitle="Registered cricketers across all 9 JDCA districts and age categories"
        action={
          <button
            id="players-add-new-btn"
            onClick={() => navigateTo('player-registration')}
            className="btn-primary"
          >
            <Plus size={16} strokeWidth={2.5} />
            <span>Add Player</span>
          </button>
        }
      />

      {/* Filter and Search Bar */}
      <div className="jdca-card p-4 mb-5" style={{ background: '#ffffff' }}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search
              size={16}
              style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#596579' }}
            />
            <input
              id="player-search-input"
              type="text"
              placeholder="Search by name, team, district..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="jdca-input"
              style={{ paddingLeft: 36 }}
            />
          </div>

          {/* District Filter */}
          <div>
            <select
              id="player-district-filter"
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="jdca-select"
            >
              {JDCA_DISTRICTS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          {/* Age Category Filter */}
          <div>
            <select
              id="player-category-filter"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="jdca-select"
            >
              {AGE_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Playing Role Filter */}
          <div>
            <select
              id="player-role-filter"
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value)}
              className="jdca-select"
            >
              {ROLES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Filter Summary & View Mode Toggle */}
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100 text-xs text-slate-500">
          <div>
            Showing <strong className="text-slate-900 font-semibold">{filteredPlayers.length}</strong> registered players
            {selectedDistrict !== 'All Districts' && <span> in <strong>{selectedDistrict}</strong></span>}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('table')}
              className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer ${
                viewMode === 'table' ? 'bg-[#2457D6] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Table View
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`px-2.5 py-1 rounded text-xs font-semibold cursor-pointer ${
                viewMode === 'grid' ? 'bg-[#2457D6] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Card View
            </button>
          </div>
        </div>
      </div>


      {/* Mobile-only nested player directory: Men/Women → District → Age Group → Player */}
      <div className="jdca-mobile-directory" aria-label="Mobile player directory">
        {mobileGroups.map((group) => {
          const districtNames = [...new Set(group.players.map((p) => p.district || 'Jabalpur'))].sort();
          return (
            <section key={group.key} className="jdca-mobile-directory__group">
              <div className={`jdca-mobile-directory__group-header ${group.key === 'women' ? 'jdca-mobile-directory__group-header--women' : ''}`}>
                <div className="jdca-mobile-directory__group-title">
                  <div className="jdca-mobile-directory__group-title-icon">
                    <Users size={17} />
                  </div>
                  <div>
                    <strong>{group.title}</strong>
                    <span>{group.subtitle}</span>
                  </div>
                </div>
                <div className="jdca-mobile-directory__count">{group.players.length}</div>
              </div>

              <div className="jdca-mobile-directory__districts">
                {districtNames.map((district) => {
                  const districtPlayers = group.players.filter((p) => (p.district || 'Jabalpur') === district);
                  const districtKey = `${group.key}-${district}`;
                  const isDistrictOpen = openMobileDistricts[districtKey] ?? true;
                  const ageGroups = mobileAgeOrder
                    .map((age) => ({ age, players: districtPlayers.filter((p) => getMobileAge(p) === age) }))
                    .filter((entry) => entry.players.length > 0);

                  return (
                    <div key={districtKey} className="jdca-mobile-directory__district">
                      <button
                        type="button"
                        className="jdca-mobile-directory__district-header"
                        onClick={() => toggleMobileDistrict(districtKey)}
                        aria-expanded={isDistrictOpen}
                      >
                        <span className="jdca-mobile-directory__district-name">
                          <span className="jdca-mobile-directory__district-pin"><MapPin size={14} /></span>
                          {district}
                        </span>
                        <span className="jdca-mobile-directory__district-meta">
                          {districtPlayers.length} players
                          {isDistrictOpen ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                        </span>
                      </button>

                      {isDistrictOpen && (
                        <div className="jdca-mobile-directory__age-list">
                          {ageGroups.map(({ age, players: agePlayers }) => {
                            const ageKey = `${districtKey}-${age}`;
                            const isAgeOpen = openMobileAges[ageKey] ?? false;
                            return (
                              <div key={ageKey} className="jdca-mobile-directory__age">
                                <button
                                  type="button"
                                  className="jdca-mobile-directory__age-header"
                                  onClick={() => toggleMobileAge(ageKey)}
                                  aria-expanded={isAgeOpen}
                                >
                                  <strong>{group.key === 'women' ? `Women's ${age}` : age}</strong>
                                  <span className="jdca-mobile-directory__age-count">{agePlayers.length}</span>
                                </button>

                                {isAgeOpen && (
                                  <div className="jdca-mobile-directory__players">
                                    {agePlayers.map((player) => (
                                      <button
                                        key={player.id}
                                        type="button"
                                        className="jdca-mobile-player"
                                        onClick={() => handlePlayerClick(player)}
                                      >
                                        <img
                                          src={player.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                                          alt=""
                                          className="jdca-mobile-player__avatar"
                                        />
                                        <span className="jdca-mobile-player__main">
                                          <span className="jdca-mobile-player__name">{player.name}</span>
                                          <span className="jdca-mobile-player__meta">
                                            {player.role || 'Batter'} · {player.team || `${district} District XI`}
                                          </span>
                                        </span>
                                        <span className="jdca-mobile-player__stats">
                                          <span className="jdca-mobile-player__runs">{player.careerRuns || 0} R</span>
                                          <span className="jdca-mobile-player__wickets">{player.wickets ?? 0} W</span>
                                          <ChevronRight size={14} />
                                        </span>
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      <div className="jdca-mobile-desktop-player-content">
      {/* Players Content Area */}
      {filteredPlayers.length === 0 ? (
        <div className="jdca-card p-12 text-center">
          <User size={36} style={{ color: '#8a99b0', margin: '0 auto 12px' }} />
          <h3 className="font-bold text-slate-900 text-base mb-1">No players found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
            Try adjusting your search keywords, district, or category filter to discover registered JDCA cricketers.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedDistrict('All Districts');
              setSelectedCategory('All Categories');
              setSelectedRole('All Roles');
            }}
            className="btn-secondary text-xs"
          >
            Reset All Filters
          </button>
        </div>
      ) : viewMode === 'table' ? (
        <div className="jdca-card overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="jdca-table">
              <thead>
                <tr>
                  <th style={{ minWidth: 220 }}>Player</th>
                  <th>District</th>
                  <th>Category</th>
                  <th>Role</th>
                  <th style={{ textAlign: 'right' }}>Matches</th>
                  <th style={{ textAlign: 'right' }}>Runs</th>
                  <th style={{ textAlign: 'right' }}>Avg</th>
                  <th style={{ textAlign: 'right' }}>Wickets</th>
                  <th style={{ textAlign: 'center' }}>Shortlist</th>
                  <th style={{ textAlign: 'right' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredPlayers.map((player) => {
                  const isShortlisted = shortlistedIds?.includes(player.id);
                  return (
                    <tr
                      key={player.id}
                      className="cursor-pointer hover:bg-slate-50/80 transition-colors"
                      onClick={() => handlePlayerClick(player)}
                    >
                      <td>
                        <div className="flex items-center gap-3">
                          <img
                            src={player.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                            alt={player.name}
                            className="w-9 h-9 rounded-full object-cover border border-slate-200 flex-shrink-0"
                          />
                          <div>
                            <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                              {player.name}
                              {player.inForm && (
                                <span className="w-2 h-2 rounded-full bg-[#0FA968]" title="In Form" />
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {player.team || `${player.district} District XI`}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-700">
                          <MapPin size={11} className="text-slate-400" />
                          {player.district || 'Jabalpur'}
                        </span>
                      </td>
                      <td>
                        <span className="badge badge-upcoming text-[10px]">
                          {player.category || 'Senior'}
                        </span>
                      </td>
                      <td>
                        <span className="text-xs font-semibold text-slate-800">
                          {player.role || 'Batter'}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }} className="font-tabular text-slate-700 font-semibold">
                        {player.matches || 0}
                      </td>
                      <td style={{ textAlign: 'right' }} className="font-tabular font-bold text-slate-900">
                        {player.careerRuns || 0}
                      </td>
                      <td style={{ textAlign: 'right' }} className="font-tabular text-slate-700">
                        {player.battingAvg ? player.battingAvg.toFixed(1) : '-'}
                      </td>
                      <td style={{ textAlign: 'right' }} className="font-tabular font-bold text-[#F05A47]">
                        {player.wickets ?? (player.role === 'Bowler' ? 14 : 0)}
                      </td>
                      <td style={{ textAlign: 'center' }}>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleShortlist(player.id);
                          }}
                          className={`p-1.5 rounded-full transition-colors ${
                            isShortlisted
                              ? 'text-[#F4B942] bg-amber-50 hover:bg-amber-100'
                              : 'text-slate-300 hover:text-slate-500'
                          }`}
                          title={isShortlisted ? 'Remove from shortlist' : 'Shortlist player'}
                        >
                          <Star size={16} fill={isShortlisted ? '#F4B942' : 'none'} />
                        </button>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePlayerClick(player);
                          }}
                          className="inline-flex items-center gap-1 text-xs font-bold text-[#2457D6] hover:text-[#1b41a8]"
                        >
                          <span>View</span>
                          <ChevronRight size={14} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPlayers.map((player) => {
            const isShortlisted = shortlistedIds?.includes(player.id);
            return (
              <div
                key={player.id}
                onClick={() => handlePlayerClick(player)}
                className="jdca-card-hover p-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={player.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}
                        alt={player.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-slate-100 shadow-xs"
                      />
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm leading-tight">{player.name}</h4>
                        <div className="text-xs text-slate-500 mt-0.5">{player.role}</div>
                        <span className="badge badge-upcoming text-[10px] mt-1">
                          {player.category || 'Senior'}
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleShortlist(player.id);
                      }}
                      className="p-1 text-slate-300 hover:text-amber-500"
                    >
                      <Star size={17} fill={isShortlisted ? '#F4B942' : 'none'} color={isShortlisted ? '#F4B942' : '#8a99b0'} />
                    </button>
                  </div>

                  <div className="flex items-center gap-1 text-xs text-slate-600 mb-3">
                    <MapPin size={12} className="text-slate-400" />
                    <span>{player.district} District</span>
                  </div>

                  {/* Quick stats row */}
                  <div className="grid grid-cols-3 gap-2 p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-center mb-3">
                    <div>
                      <div className="text-[10px] font-semibold text-slate-500 uppercase">Runs</div>
                      <div className="text-sm font-bold text-slate-900 font-tabular">{player.careerRuns || 0}</div>
                    </div>
                    <div>
                      <div className="text-[10px] font-semibold text-slate-500 uppercase">Avg</div>
                      <div className="text-sm font-bold text-slate-900 font-tabular">{player.battingAvg ? player.battingAvg.toFixed(1) : '-'}</div>
                    </div>
                    <div>
                      <div className="text-[10px] font-semibold text-slate-500 uppercase">Wkts</div>
                      <div className="text-sm font-bold text-[#F05A47] font-tabular">{player.wickets ?? (player.role === 'Bowler' ? 14 : 0)}</div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Matches: {player.matches || 0}</span>
                  <span className="text-[#2457D6] font-bold flex items-center gap-0.5">
                    Full Profile <ChevronRight size={14} />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
      </div>
    </div>
  );
}
