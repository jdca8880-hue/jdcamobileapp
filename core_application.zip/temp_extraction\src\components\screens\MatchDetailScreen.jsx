import React from 'react';
import { ArrowLeft, CalendarDays, MapPin, ShieldCheck, Trophy, Newspaper, Radio, Users } from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import MatchScorecard from '../ui/MatchScorecard';
import MatchMediaReport from '../ui/MatchMediaReport';
import { calculateMatchHighlights } from '../../engine/matchSummaryEngine';

export default function MatchDetailScreen() {
  const { matches = [], activeMatchId, navigateTo, goBack } = useCricket();
  const match = matches.find(m => m.id === activeMatchId) || matches[0];
  if (!match) return null;
  const h = calculateMatchHighlights(match);
  const live = match.status === 'LIVE' || match.status === 'IN_PROGRESS';

  return <div className="match-detail-page">
    <button className="match-detail-page__back" onClick={goBack}><ArrowLeft size={16}/> Matches Directory</button>
    <header className="match-detail-hero">
      <div className="match-detail-hero__eyebrow">{match.tournament || 'JDCA OFFICIAL FIXTURE'} · {match.stage || match.category || match.format}</div>
      <h1>{match.teamA?.name} <span>vs</span> {match.teamB?.name}</h1>
      <p><CalendarDays size={14}/> {match.date || 'Match date'} · <MapPin size={14}/> {match.venue || 'JDCA Ground'}</p>
      <div className="match-detail-hero__scores">
        <div><span>{match.teamA?.name}</span><strong>{match.teamA?.score || '—'}</strong><small>{match.teamA?.overs || ''}</small></div>
        <div className="match-detail-hero__vs">{live ? <><Radio size={13}/> LIVE</> : 'FINAL'}</div>
        <div><span>{match.teamB?.name}</span><strong>{match.teamB?.score || '—'}</strong><small>{match.teamB?.overs || ''}</small></div>
      </div>
      {!live && <div className="match-detail-hero__result">{match.resultText || match.result || 'Official result'}</div>}
    </header>

    <div className="match-detail-grid">
      <section><div className="section-kicker"><ShieldCheck size={15}/> MATCH INFORMATION</div><div className="match-info-list">
        {[['Tournament', match.tournament],['Format', `${match.format || '—'} · ${match.ballType || '—'}`],['Category', match.category || match.ageGroup || '—'],['Venue', match.venue || '—'],['Toss', match.tossDecision || '—'],['Officials', (match.officials || []).join(', ') || 'JDCA officials assigned']].map(([k,v])=><div key={k}><small>{k}</small><b>{v}</b></div>)}
      </div></section>
      <section><div className="section-kicker"><Trophy size={15}/> MATCH HIGHLIGHTS</div><div className="match-highlight-grid">
        {[['TOP BATTER',h.topBatter],['TOP BOWLER',h.topBowler],['PLAYER OF THE MATCH',h.playerOfMatch]].map(([label,p],i)=><div className={`match-highlight match-highlight--${i}`} key={label}><small>{label}</small><strong>{p?.name || 'To be confirmed'}</strong><span>{p?.stat || p?.batting || p?.bowling || 'Official match data'}</span></div>)}
      </div></section>
    </div>

    <section className="match-detail-block"><div className="section-kicker"><Users size={15}/> FULL SCORECARD</div><MatchScorecard match={match}/></section>
    {!live && <section className="match-detail-block"><div className="section-kicker"><Newspaper size={15}/> MEDIA REPORT</div><MatchMediaReport match={match}/></section>}
    {live && <button className="match-detail-live-button" onClick={() => navigateTo('scoring')}><Radio size={17}/> Open Live Scoring Console</button>}
  </div>;
}
