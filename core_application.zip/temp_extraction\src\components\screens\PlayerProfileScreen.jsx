import React, { useState } from 'react';
import { 
  Award, 
  TrendingUp, 
  MapPin, 
  Share2, 
  ArrowLeft, 
  Star, 
  CheckCircle2, 
  Sparkles,
  Flame,
  BarChart3,
  Sliders,
  Calendar,
  Shield,
  FileText
} from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { TabBar } from '../ui/PageHeader';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

export default function PlayerProfileScreen() {
  const { selectedPlayer, setCompareModalOpen, goBack, shortlistedIds, toggleShortlist } = useCricket();
  const [activeTab, setActiveTab] = useState('Overview');

  const player = selectedPlayer || {
    id: 'rohan-sharma',
    name: 'Rohan Sharma',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    team: 'Jabalpur Kings XI',
    role: 'Batter',
    battingStyle: 'Right-Hand Batter',
    bowlingStyle: 'Right-Arm Off Break',
    category: 'Senior',
    district: 'Jabalpur',
    careerRuns: 4258,
    battingAvg: 42.5,
    strikeRate: 145.2,
    highScore: '118*',
    matches: 112,
    fifties: 28,
    hundreds: 6,
    fours: 412,
    sixes: 85,
    wickets: 0,
    scoringAreas: { offSide: 45, legSide: 35, behindSquare: 10, fine: 10 },
    awards: ['Best Batter 2023-24', 'Man of the Series - District T20 Cup'],
    achievements: ['1000 Career Runs', '100+ Matches Played'],
  };

  const isShortlisted = shortlistedIds?.includes(player.id);

  const tabs = [
    { id: 'Overview', label: 'Overview' },
    { id: 'Batting', label: 'Batting Analysis' },
    { id: 'Bowling', label: 'Bowling' },
    { id: 'Selection', label: 'Selection History' },
  ];

  // Pie Chart Data
  const pieData = [
    { name: 'Off Side', value: player.scoringAreas?.offSide || 40, color: '#2457D6' },
    { name: 'Leg Side', value: player.scoringAreas?.legSide || 35, color: '#F4B942' },
    { name: 'Behind Sq', value: player.scoringAreas?.behindSquare || 15, color: '#0FA968' },
    { name: 'Fine Leg', value: player.scoringAreas?.fine || 10, color: '#F05A47' },
  ];

  return (
    <div className="fade-in-up" style={{ padding: '24px 20px 100px', maxWidth: 1000, margin: '0 auto' }}>
      
      {/* Top Back & Quick Action Row */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 text-xs font-bold text-[#2457D6] hover:underline cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>Back to Players</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => toggleShortlist(player.id)}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg border text-xs font-bold cursor-pointer transition-all ${
              isShortlisted
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Star size={13} fill={isShortlisted ? '#F4B942' : 'none'} color={isShortlisted ? '#F4B942' : '#596579'} />
            <span>{isShortlisted ? 'Shortlisted' : 'Shortlist'}</span>
          </button>

          <button
            onClick={() => setCompareModalOpen(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#2457D6] text-white text-xs font-bold hover:bg-[#1b41a8] cursor-pointer"
          >
            <Sliders size={13} />
            <span>Compare</span>
          </button>
        </div>
      </div>

      {/* ── Official Midnight Ink Profile Banner ── */}
      <div className="rounded-2xl p-5 sm:p-6 mb-5 shadow-sm text-white relative overflow-hidden" style={{ background: '#101827' }}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 relative z-10">
          <img
            src={player.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80'}
            alt={player.name}
            className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-white/20 shadow-md flex-shrink-0"
          />

          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {player.name}
              </h1>
              <span className="badge badge-upcoming text-[11px]">
                {player.category || 'Senior'}
              </span>
              <span className="badge badge-live text-[11px]">
                JDCA Registered
              </span>
            </div>

            <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-300 flex-wrap">
              <span className="font-semibold text-white">{player.role}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <MapPin size={12} className="text-blue-400" />
                {player.district} District
              </span>
              <span>•</span>
              <span>{player.team || `${player.district} XI`}</span>
            </div>

            <div className="text-xs text-slate-400 mt-1">
              {player.battingStyle || 'Right-Hand Bat'} • {player.bowlingStyle || 'Right-Arm Medium'}
            </div>
          </div>
        </div>

        {/* Highlight Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-5 pt-4 border-t border-white/10 text-center">
          <div className="p-2.5 rounded-xl bg-white/5">
            <div className="text-[10px] font-bold text-slate-400 uppercase">Matches</div>
            <div className="text-lg font-extrabold text-white font-tabular">{player.matches || 0}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5">
            <div className="text-[10px] font-bold text-slate-400 uppercase">Career Runs</div>
            <div className="text-lg font-extrabold text-[#F4B942] font-tabular">{player.careerRuns || 0}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5">
            <div className="text-[10px] font-bold text-slate-400 uppercase">Batting Avg</div>
            <div className="text-lg font-extrabold text-white font-tabular">{player.battingAvg ? player.battingAvg.toFixed(1) : '-'}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5">
            <div className="text-[10px] font-bold text-slate-400 uppercase">High Score</div>
            <div className="text-lg font-extrabold text-white font-tabular">{player.highScore || '-'}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-white/5">
            <div className="text-[10px] font-bold text-slate-400 uppercase">Wickets</div>
            <div className="text-lg font-extrabold text-[#F05A47] font-tabular">{player.wickets ?? (player.role === 'Bowler' ? 14 : 0)}</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-5">
        <TabBar tabs={tabs} active={activeTab} onChange={setActiveTab} />
      </div>

      {/* ── TAB 1: OVERVIEW ── */}
      {activeTab === 'Overview' && (
        <div className="space-y-5">
          
          {/* Awards & Distinctions (Mango Gold highlight) */}
          <div className="jdca-card p-5 border-l-4 border-l-[#F4B942]">
            <div className="flex items-center gap-2 mb-3">
              <Award size={18} className="text-[#F4B942]" />
              <h3 className="font-extrabold text-slate-900 text-sm">Association Distinctions & Awards</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {(player.awards || ['Best District Batter 2024', 'Player of the Match - Division Final']).map((award, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-200 text-xs font-bold text-amber-900 flex items-center gap-1.5"
                >
                  <span>🏆</span>
                  <span>{award}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Scoring Areas Wagon Distribution */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="jdca-card p-5">
              <h3 className="font-bold text-slate-900 text-sm mb-1">Scoring Zone Breakdown</h3>
              <p className="text-xs text-slate-500 mb-4">Boundary and strike distribution across ground sectors</p>
              
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                {pieData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ background: item.color }} />
                    <span className="text-slate-600">{item.name}: <strong>{item.value}%</strong></span>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance by Season */}
            <div className="jdca-card p-5">
              <h3 className="font-bold text-slate-900 text-sm mb-1">Career Breakdown</h3>
              <p className="text-xs text-slate-500 mb-4">Official JDCA tournament statistics</p>

              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-slate-600">Fifties / Hundreds</span>
                  <span className="font-bold text-slate-900 font-tabular">{player.fifties || 0} / {player.hundreds || 0}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-slate-600">Boundaries (4s / 6s)</span>
                  <span className="font-bold text-slate-900 font-tabular">{player.fours || 0} / {player.sixes || 0}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-slate-600">Career Strike Rate</span>
                  <span className="font-bold text-[#2457D6] font-tabular">{player.strikeRate || '135.0'}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-slate-600">Registered District Club</span>
                  <span className="font-bold text-slate-900">{player.club || `${player.district} Cricket Club`}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 2: BATTING ── */}
      {activeTab === 'Batting' && (
        <div className="jdca-card p-5">
          <h3 className="font-bold text-slate-900 text-sm mb-3">Detailed Batting Metrics</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Innings</div>
              <div className="text-lg font-extrabold text-slate-900 font-tabular">{player.matches || 24}</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Dot Ball %</div>
              <div className="text-lg font-extrabold text-slate-900 font-tabular">34.2%</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Boundary %</div>
              <div className="text-lg font-extrabold text-[#2457D6] font-tabular">19.5%</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Strike Rate</div>
              <div className="text-lg font-extrabold text-slate-900 font-tabular">{player.strikeRate || '142.5'}</div>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 3: BOWLING ── */}
      {activeTab === 'Bowling' && (
        <div className="jdca-card p-5">
          <h3 className="font-bold text-slate-900 text-sm mb-3">Bowling Records</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Wickets</div>
              <div className="text-lg font-extrabold text-[#F05A47] font-tabular">{player.wickets || (player.role === 'Bowler' ? 14 : 0)}</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Economy</div>
              <div className="text-lg font-extrabold text-slate-900 font-tabular">{player.economy || (player.role === 'Bowler' ? '6.4' : '-')}</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Best Figures</div>
              <div className="text-lg font-extrabold text-slate-900 font-tabular">{player.bestBowling || (player.role === 'Bowler' ? '4/18' : '-')}</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] font-bold text-slate-400 uppercase">Average</div>
              <div className="text-lg font-extrabold text-slate-900 font-tabular">{player.average ? player.average.toFixed(1) : '-'}</div>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 4: SELECTION HISTORY ── */}
      {activeTab === 'Selection' && (
        <div className="jdca-card overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-sm">Official Selection History</h3>
            <p className="text-xs text-slate-500">Recorded selections in JDCA district rosters and MPCA state trials</p>
          </div>

          <div className="overflow-x-auto">
            <table className="jdca-table">
              <thead>
                <tr>
                  <th>Tournament / Championship</th>
                  <th>Category</th>
                  <th>Representing</th>
                  <th>Season</th>
                  <th style={{ textAlign: 'right' }}>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr className="hover:bg-slate-50">
                  <td>
                    <div className="font-bold text-slate-900 text-sm">JDCA Senior District Trophy</div>
                  </td>
                  <td><span className="badge badge-upcoming text-[10px]">Senior</span></td>
                  <td className="text-xs text-slate-700 font-semibold">{player.district} District XI</td>
                  <td className="text-xs text-slate-600 font-tabular">2026</td>
                  <td style={{ textAlign: 'right' }}>
                    <span className="badge badge-live text-[10px]">Selected (Squad)</span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50">
                  <td>
                    <div className="font-bold text-slate-900 text-sm">MPCA Inter-District Championship</div>
                  </td>
                  <td><span className="badge badge-upcoming text-[10px]">Senior</span></td>
                  <td className="text-xs text-slate-700 font-semibold">Jabalpur Division</td>
                  <td className="text-xs text-slate-600 font-tabular">2025</td>
                  <td style={{ textAlign: 'right' }}>
                    <span className="badge badge-completed text-[10px]">Played (Playing XI)</span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-50">
                  <td>
                    <div className="font-bold text-slate-900 text-sm">District T20 Blast</div>
                  </td>
                  <td><span className="badge badge-upcoming text-[10px]">Senior</span></td>
                  <td className="text-xs text-slate-700 font-semibold">{player.team || 'District XI'}</td>
                  <td className="text-xs text-slate-600 font-tabular">2024</td>
                  <td style={{ textAlign: 'right' }}>
                    <span className="badge badge-completed text-[10px]">Champions</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
}
