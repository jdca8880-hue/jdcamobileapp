import React, { useState } from 'react';
import { Camera, User, ArrowLeft, Check, Sparkles, AlertCircle, Shield, CheckCircle2 } from 'lucide-react';
import { useCricket } from '../../context/CricketContext';
import { PlayerRegistrationSchema } from '../../engine/validationSchemas';
import { PageHeader } from '../ui/PageHeader';

const JDCA_DISTRICTS = [
  'Jabalpur',
  'Katni',
  'Narsinghpur',
  'Seoni',
  'Mandla',
  'Balaghat',
  'Chhindwara',
  'Dindori',
  'Pandhurna'
];

const AGE_CATEGORIES = [
  'Senior',
  'Under-22',
  'Under-18',
  'Under-15',
  'Under-13',
  "Women's Senior",
  "Women's Under-22",
  "Women's Under-18"
];

const ROLES = ['Batter', 'Bowler', 'All-Rounder', 'Wicket Keeper'];
const BATTING_STYLES = ['Right-Hand Bat', 'Left-Hand Bat'];
const BOWLING_STYLES = [
  'None (Pure Batter)',
  'Right-Arm Fast',
  'Right-Arm Medium Fast',
  'Right-Arm Off Spin',
  'Right-Arm Leg Spin',
  'Left-Arm Fast',
  'Left-Arm Orthodox Spin',
  'Left-Arm Chinaman'
];

export default function PlayerRegistrationScreen() {
  const { registerPlayer, goBack } = useCricket();

  const [name, setName] = useState('');
  const [role, setRole] = useState('Batter');
  const [battingStyle, setBattingStyle] = useState('Right-Hand Bat');
  const [bowlingStyle, setBowlingStyle] = useState('None (Pure Batter)');
  const [district, setDistrict] = useState('Jabalpur');
  const [category, setCategory] = useState('Senior');
  const [age, setAge] = useState(20);
  const [avatar, setAvatar] = useState('https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80');
  const [formErrors, setFormErrors] = useState({});
  const [registeredSuccess, setRegisteredSuccess] = useState(false);

  const avatarPresets = [
    'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80'
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors({});

    const formData = {
      name,
      role,
      battingStyle,
      bowlingStyle,
      district,
      category,
      age: Number(age),
      avatar
    };

    const validation = PlayerRegistrationSchema.safeParse(formData);
    if (!validation.success) {
      const fieldErrors = {};
      validation.error.errors.forEach((err) => {
        const field = err.path[0];
        if (field) fieldErrors[field] = err.message;
      });
      setFormErrors(fieldErrors);
      return;
    }

    registerPlayer(validation.data);
    setRegisteredSuccess(true);
    setTimeout(() => {
      goBack();
    }, 1500);
  };

  return (
    <div className="fade-in-up" style={{ padding: '24px 20px 100px', maxWidth: 850, margin: '0 auto' }}>
      
      {/* Top Back Navigation */}
      <div className="mb-4">
        <button
          onClick={goBack}
          className="flex items-center gap-1.5 text-xs font-bold text-[#2457D6] hover:underline cursor-pointer"
        >
          <ArrowLeft size={14} />
          <span>Back to Players</span>
        </button>
      </div>

      <PageHeader
        title="Official Player Registration"
        subtitle="Register cricketer into the Jabalpur District Cricket Association Central Registry"
      />

      {registeredSuccess && (
        <div className="mb-5 p-4 rounded-xl bg-[#e8f8ef] border border-[#c2edda] flex items-center gap-3 text-[#0a7d4e]">
          <CheckCircle2 size={20} className="text-[#0FA968]" />
          <div>
            <div className="font-bold text-sm">Player Successfully Registered</div>
            <div className="text-xs">Assigned to {district} District roster. Redirecting...</div>
          </div>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Section 1: Personal & Photo Information */}
        <div className="jdca-card p-5">
          <div className="section-label mb-4">1. Identification & Photo</div>

          <div className="flex flex-col sm:flex-row items-center gap-6 mb-5">
            <div className="flex flex-col items-center">
              <div className="w-24 h-24 rounded-full border-2 border-dashed border-slate-300 p-1 flex items-center justify-center overflow-hidden bg-slate-50 relative group">
                <img
                  src={avatar}
                  alt="Player preview"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-1">Official Headshot</span>
            </div>

            <div className="flex-1">
              <label className="jdca-label">Choose from Verified Presets</label>
              <div className="flex items-center gap-2 mt-1">
                {avatarPresets.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setAvatar(preset)}
                    className={`w-11 h-11 rounded-full overflow-hidden border-2 transition-transform cursor-pointer ${
                      avatar === preset ? 'border-[#2457D6] scale-105 shadow-sm' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={preset} alt={`preset-${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="jdca-label">Full Registered Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Rahul Sharma"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={`jdca-input ${formErrors.name ? 'border-red-500' : ''}`}
              />
              {formErrors.name && (
                <span className="text-[11px] text-red-500 mt-1 block">{formErrors.name}</span>
              )}
            </div>

            <div>
              <label className="jdca-label">Age (Years) *</label>
              <input
                type="number"
                min="10"
                max="50"
                required
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className={`jdca-input ${formErrors.age ? 'border-red-500' : ''}`}
              />
              {formErrors.age && (
                <span className="text-[11px] text-red-500 mt-1 block">{formErrors.age}</span>
              )}
            </div>
          </div>
        </div>

        {/* Section 2: District Affiliation & Age Category */}
        <div className="jdca-card p-5">
          <div className="section-label mb-4">2. District Affiliation & Age Group</div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="jdca-label">JDCA District Unit *</label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="jdca-select"
              >
                {JDCA_DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d} District
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="jdca-label">Age Competition Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="jdca-select"
              >
                {AGE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Section 3: Playing Specialisation */}
        <div className="jdca-card p-5">
          <div className="section-label mb-4">3. Cricket Playing Specialisation</div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="jdca-label">Primary Playing Role *</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="jdca-select"
              >
                {ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="jdca-label">Batting Style *</label>
              <select
                value={battingStyle}
                onChange={(e) => setBattingStyle(e.target.value)}
                className="jdca-select"
              >
                {BATTING_STYLES.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="jdca-label">Bowling Style</label>
              <select
                value={bowlingStyle}
                onChange={(e) => setBowlingStyle(e.target.value)}
                className="jdca-select"
              >
                {BOWLING_STYLES.map((bw) => (
                  <option key={bw} value={bw}>
                    {bw}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={goBack}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            id="submit-player-registration-btn"
            className="btn-primary"
            style={{ padding: '10px 24px' }}
          >
            <span>Confirm & Register Player</span>
          </button>
        </div>

      </form>
    </div>
  );
}
