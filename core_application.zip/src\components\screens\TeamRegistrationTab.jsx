import React, { useState, useEffect } from 'react';
import { useCricket } from '../../context/CricketContext';
import { Users, Shield, Plus, X, Search, CheckCircle2, AlertTriangle, UserPlus, Camera, Trash2 } from 'lucide-react';
import CloudinaryAvatar from '../ui/CloudinaryAvatar';
import { api, calculatePlayerAge } from '../../lib/api';
import { supabase } from '../../lib/supabase';

const JDCA_DISTRICTS = [
  'Jabalpur', 'Katni', 'Narsinghpur', 'Seoni', 'Mandla', 
  'Balaghat', 'Chhindwara', 'Dindori', 'Pandhurna'
];

export default function TeamRegistrationTab({ userRole }) {
  const { players = [], teams = [], setTeams } = useCricket();
  
  const [districtTeams, setDistrictTeams] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamDistrict, setNewTeamDistrict] = useState(JDCA_DISTRICTS[0]);
  const [newTeamCategory, setNewTeamCategory] = useState('Senior');
  const [newTeamGender, setNewTeamGender] = useState('Men');
  
  const [activeTeamId, setActiveTeamId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [teamPlayers, setTeamPlayers] = useState([]);
  
  const [ageCategories, setAgeCategories] = useState([]);
  const [dbDistricts, setDbDistricts] = useState([]);
  const [showQuickRegister, setShowQuickRegister] = useState(false);
  const [newPlayerFullName, setNewPlayerFullName] = useState('');
  const [newPlayerPhone, setNewPlayerPhone] = useState('');
  const [newPlayerPrimaryRole, setNewPlayerPrimaryRole] = useState('Batter');
  const [newPlayerBattingStyle, setNewPlayerBattingStyle] = useState('Right-Hand Bat');
  const [newPlayerBowlingStyle, setNewPlayerBowlingStyle] = useState('None (Pure Batter)');
  const [newPlayerDateOfBirth, setNewPlayerDateOfBirth] = useState('');
  const [newPlayerGender, setNewPlayerGender] = useState('Men');
  const [newPlayerAvatarUrl, setNewPlayerAvatarUrl] = useState('');
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [newPlayerDistrict, setNewPlayerDistrict] = useState('Jabalpur');
  const [isRegistering, setIsRegistering] = useState(false);
  const { registerPlayer } = useCricket();
    const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploadingAvatar(true);
    const formData = new FormData();
    formData.append('file', file);
    const uploadPreset = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET || 'jdcaunsignedupload';
    formData.append('upload_preset', uploadPreset);

    try {
      const cloudName = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME || 'gglzv8pn';
      const res = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (data.secure_url) {
        setNewPlayerAvatarUrl(data.secure_url);
      } else if (data.error) {
        alert(data.error.message || 'Failed to upload image.');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Failed to upload image. Please try again.');
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  const handleQuickRegister = async () => {
    if (!newPlayerFullName.trim()) return;
    setIsRegistering(true);
    try {
      await registerPlayer({ full_name: newPlayerFullName, phone: newPlayerPhone, district: newPlayerDistrict, date_of_birth: newPlayerDateOfBirth || '2000-01-01', gender: newPlayerGender, primary_role: newPlayerPrimaryRole, batting_style: newPlayerBattingStyle, bowling_style: newPlayerBowlingStyle, avatar_url: newPlayerAvatarUrl });
      setShowQuickRegister(false);
      setNewPlayerFullName('');
      setNewPlayerPhone('');
      setNewPlayerAvatarUrl('');
      // Wait briefly for sync then search for the newly created player
      setTimeout(() => setSearchQuery(newPlayerFullName), 500);
    } catch (err) {
      console.error(err);
      alert('Failed to register player');
    } finally {
      setIsRegistering(false);
    }
  };

  useEffect(() => {
    const fetchDropdowns = async () => {
      const [{ data: ac }, { data: dist }] = await Promise.all([
        supabase.from('age_categories').select('*').eq('is_active', true),
        supabase.from('districts').select('*').eq('is_active', true)
      ]);
      if (ac && ac.length > 0) {
        setAgeCategories(ac);
        // Find a default that matches the initial gender ('Men')
        const defaultAc = ac.find(a => {
          const n = a.name.toLowerCase();
          return n.includes('men') || n.includes('boy') || (!n.includes('women') && !n.includes('girl'));
        });
        if(defaultAc) setNewTeamCategory(defaultAc.id);
        else setNewTeamCategory(ac[0].id);
      }
      if (dist && dist.length > 0) {
        setDbDistricts(dist);
        setNewTeamDistrict(dist[0].id);
      } else {
        // Fallback to manual if DB fails
        const mockDistricts = JDCA_DISTRICTS.map((d, i) => ({ id: `mock-${i}`, name: d }));
        setDbDistricts(mockDistricts);
        setNewTeamDistrict(mockDistricts[0].id);
      }
    };
    fetchDropdowns();
  }, []);

  useEffect(() => {
    // Filter out only DISTRICT_TEAM
    const dTeams = teams.filter(t => t.team_type === 'DISTRICT_TEAM');
    setDistrictTeams(dTeams);
  }, [teams]);

  useEffect(() => {
    if (activeTeamId) {
      loadTeamPlayers(activeTeamId);
    }
  }, [activeTeamId]);

  const loadTeamPlayers = async (teamId) => {
    try {
      const { data, error } = await supabase
        .from('team_players')
        .select('player_id')
        .eq('team_id', teamId);
      if (error) throw error;
      setTeamPlayers(data.map(tp => tp.player_id));
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateTeam = async (e) => {
    e.preventDefault();
    if (!newTeamName) return;
    
    try {
      const defaults = await api.getDefaults();
      
      const { data: teamData, error: teamError } = await supabase
        .from('teams')
        .insert([{
          name: newTeamName,
          short_name: newTeamName.substring(0, 3).toUpperCase(),
          season: new Date().getFullYear().toString(),
          district_id: newTeamDistrict.startsWith('mock-') ? defaults.district_id : newTeamDistrict,
          age_category_id: newTeamCategory,
          gender: newTeamGender,
          is_active: true,
          team_type: 'DISTRICT_TEAM'
        }])
        .select('*, district:district_id(*), age_category:age_category_id(*)')
        .single();
        
      if (teamError) throw teamError;
      
      // Also create a selection process so it shows up in Team Selection!
      const { data: processData, error: processError } = await supabase
        .from('selection_processes')
        .insert([{
          name: newTeamName + ' Selection',
          season_id: 1, // Default to first season or similar
          age_category_id: newTeamCategory,
          gender: newTeamGender,
          target_squad_size: 20,
          status: 'UPCOMING',
          process_type: 'DISTRICT_TEAM',
          target_district_id: newTeamDistrict.startsWith('mock-') ? defaults.district_id : newTeamDistrict
        }])
        .select()
        .single();
        
      if (!processError && processData) {
        // Assign the current admin to this process so they can see it
        const { data: userData } = await supabase.auth.getUser();
        if (userData?.user?.id) {
          await supabase.from('selector_assignments').insert([{
            selection_process_id: processData.id,
            selector_id: userData.user.id,
            is_lead_selector: true
          }]);
        }
      }
      
      setTeams(prev => [teamData, ...prev]);
      setIsCreating(false);
      setNewTeamName('');
    } catch (err) {
      console.error(err);
      alert('Failed to create team: ' + err.message);
    }
  };

  const handleDeleteTeam = async (id, e) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this team?')) return;
    try {
      const { api } = await import('../../lib/api');
      await api.deleteTeam(id);
      setTeams(prev => prev.filter(t => t.id !== id));
      if (activeTeamId === id) setActiveTeamId(null);
    } catch (err) {
      console.error(err);
      alert(err.message || 'Failed to delete team.');
    }
  };

  const handleTogglePlayer = async (playerId) => {
    if (!activeTeamId) return;
    
    const isAssigned = teamPlayers.includes(playerId);
    try {
      if (isAssigned) {
        await supabase
          .from('team_players')
          .delete()
          .eq('team_id', activeTeamId)
          .eq('player_id', playerId);
        setTeamPlayers(prev => prev.filter(id => id !== playerId));
      } else {
        await supabase
          .from('team_players')
          .insert([{ team_id: activeTeamId, player_id: playerId }]);
        setTeamPlayers(prev => [...prev, playerId]);
      }
    } catch (err) {
      console.error(err);
      alert('Failed to update player assignment');
    }
  };

  const activeTeam = districtTeams.find(t => t.id === activeTeamId);

  const filteredPlayers = players.filter(p => {
    // Only filter by gender if both the team and player have gender set
    if (activeTeam?.gender && p.gender && p.gender !== activeTeam.gender) return false;
    if (searchQuery) {
      const pName = p.name || p.full_name || '';
      return pName.toLowerCase().includes(searchQuery.toLowerCase()) || 
             (p.district || '').toLowerCase().includes(searchQuery.toLowerCase());
    }
    return true;
  });

  const filteredAgeCategories = ageCategories.filter(ac => {
    const n = ac.name.toLowerCase();
    if (newTeamGender === 'Women') {
      return n.includes('women') || n.includes('girl') || (!n.includes('men') && !n.includes('boy'));
    } else {
      return n.includes('men') || n.includes('boy') || (!n.includes('women') && !n.includes('girl'));
    }
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-900">District Team Management</h3>
          <p className="text-xs text-slate-500">Create local teams and manually assign players to grant them district tags.</p>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="btn-primary text-xs flex items-center gap-1.5"
        >
          <Plus size={14} /> New District Team
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Teams List */}
        <div className="lg:col-span-4 space-y-4">
          <div className="jdca-card p-4 h-[350px] lg:h-[600px] overflow-y-auto shadow-sm">
            <h4 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-2 sticky top-0 bg-white/95 backdrop-blur z-10 py-1">
              <Shield size={16} className="text-cobalt" />
              Registered District Teams
            </h4>
            
            {districtTeams.length === 0 ? (
              <div className="text-center p-6 text-slate-400">
                <p className="text-xs">No district teams created yet.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {districtTeams.map(team => (
                  <div 
                    key={team.id}
                    onClick={() => setActiveTeamId(team.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition ${activeTeamId === team.id ? 'border-cobalt bg-blue-50/50' : 'border-slate-200 hover:border-slate-300 bg-white'}`}
                  >
                    <div className="font-bold text-sm text-slate-900">{team.name}</div>
                    <div className="text-xs text-slate-500 flex justify-between mt-1 items-center">
                      <span>{team.age_category?.name || "Category"} � {team.gender}</span>
                      <button onClick={(e) => handleDeleteTeam(team.id, e)} className="text-slate-400 hover:text-rose-500 p-1 hover:bg-rose-50 rounded transition-colors" title="Delete Team"><Trash2 size={14} /></button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Player Assignment */}
        <div className="lg:col-span-8">
          <div className="jdca-card p-4 lg:p-5 h-[500px] lg:h-[600px] flex flex-col shadow-sm">
            {!activeTeam ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50 rounded-xl border border-slate-100 border-dashed m-2">
                <Users size={48} className="mb-3 opacity-30" />
                <p className="text-sm font-medium">Select a team to manage its players</p>
              </div>
            ) : (
              <>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 border-b border-slate-100 pb-4 gap-4 sm:gap-0">
                  <div>
                    <h4 className="font-bold text-base text-slate-900">{activeTeam.name}</h4>
                    <p className="text-xs text-slate-500 font-medium">Currently assigned: <span className="text-cobalt font-bold">{teamPlayers.length}</span> players</p>
                  </div>
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
                    <div className="relative w-full sm:w-64">
                      <Search className="absolute left-3 top-2.5 text-slate-400" size={14} />
                      <input 
                        type="text" 
                        placeholder="Search players..."
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-cobalt focus:ring-2 focus:ring-cobalt/20 transition-all"
                      />
                    </div>
                    <button onClick={() => { setNewPlayerGender(activeTeam?.gender || 'Men'); setNewPlayerDistrict(activeTeam?.district_id || JDCA_DISTRICTS[0]); setShowQuickRegister(true); }} className="px-3 py-2 bg-cobalt/10 hover:bg-cobalt/20 text-cobalt text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition whitespace-nowrap"><UserPlus size={14}/> New Player</button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto pr-2 space-y-2.5 custom-scrollbar">
                  {filteredPlayers.map(player => {
                    const isAssigned = teamPlayers.includes(player.id);
                    
                    // Age eligibility check
                    const maxAge = activeTeam?.age_category?.maximum_age;
                    const playerAge = calculatePlayerAge(player.date_of_birth || player.dob);
                    const isIneligible = maxAge && playerAge > maxAge;

                    return (
                      <div 
                        key={player.id}
                        className={`flex flex-col p-3 border rounded-xl transition-all duration-200 ${isIneligible ? 'bg-slate-50 border-slate-200 opacity-70' : 'bg-white border-slate-100 hover:border-slate-300 hover:shadow-sm'}`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-0">
                          <div className="flex items-center gap-3">
                            <img 
                              src={player.avatar || player.avatar_url || ''} 
                              alt={player.name || player.full_name}
                              className="w-10 h-10 rounded-full bg-slate-200 object-cover shadow-sm"
                            />
                            <div>
                              <div className="font-bold text-sm text-slate-900">{player.name || player.full_name || 'Unknown Player'}</div>
                              <div className="text-xs text-slate-500 font-medium mt-0.5">
                                {player.district || 'Unknown District'} • Age: <span className={playerAge !== 99 ? 'text-slate-700 font-semibold' : ''}>{playerAge !== 99 ? playerAge : 'N/A'}</span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-end">
                          {isIneligible ? (
                            <div className="px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-slate-200 text-slate-500 cursor-not-allowed">
                              Ineligible
                            </div>
                          ) : (
                            <button
                              onClick={() => handleTogglePlayer(player.id)}
                              className={`px-3 py-1.5 w-full sm:w-auto rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${isAssigned ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100' : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-transparent'}`}
                            >
                              {isAssigned ? <><CheckCircle2 size={14} /> Assigned</> : <><Plus size={14} /> Assign</>}
                            </button>
                          )}
                          </div>
                        </div>
                        
                        {isIneligible && (
                          <div className="mt-2 text-[11px] font-medium text-coral-600 flex items-start gap-1.5 bg-coral-50/50 p-2 rounded-lg border border-coral-100">
                            <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                            <span>Player age ({playerAge}) exceeds the limit ({maxAge}) for {activeTeam.age_category?.name}. Older players cannot play down.</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* CREATE MODAL */}
      {isCreating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-800/80">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-base">Register District Team</h3>
              <button onClick={() => setIsCreating(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateTeam} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Team Name</label>
                <input
                  type="text"
                  required
                  value={newTeamName}
                  onChange={(e) => setNewTeamName(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-sm focus:outline-none focus:border-blue-500"
                  placeholder="e.g. Star Cricket Club Jabalpur"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">District Focus</label>
                <select
                  value={newTeamDistrict}
                  onChange={(e) => setNewTeamDistrict(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 text-sm focus:outline-none focus:border-blue-500"
                >
                  {dbDistricts.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Gender</label>
                  <select
                    value={newTeamGender}
                    onChange={(e) => setNewTeamGender(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-sm focus:outline-none focus:border-blue-500"
                  >
                    <option value="Men">Men's Cricket</option>
                    <option value="Women">Women's Cricket</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Age Category</label>
                  <select
                    value={newTeamCategory}
                    onChange={(e) => setNewTeamCategory(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 text-sm focus:outline-none focus:border-blue-500"
                  >
                    {filteredAgeCategories.map(ac => <option key={ac.id} value={ac.id}>{ac.name}</option>)}
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 mt-6">
                <button type="button" onClick={() => setIsCreating(false)} className="px-4 py-2 text-sm font-semibold text-slate-600">
                  Cancel
                </button>
                <button type="submit" className="btn-primary text-sm">
                  Register Team
                </button>
              </div>
            </form>
          </div>
        </div>
      )}


      {showQuickRegister && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-xl">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="font-bold text-slate-800">Quick Player Registration</h3>
              <button onClick={() => setShowQuickRegister(false)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
            </div>
                                    <div className="p-4 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="flex flex-col items-center mb-4">
                <label className="relative cursor-pointer group block">
                  <CloudinaryAvatar src={newPlayerAvatarUrl} alt="Avatar" className={"w-20 h-20 rounded-full object-cover border-[3px] border-slate-100 shadow-sm transition " + (isUploadingAvatar ? "opacity-50" : "group-hover:opacity-80")} />
                  <div className="absolute bottom-0 right-0 w-6 h-6 bg-cobalt rounded-full flex items-center justify-center text-white border-2 border-white shadow-sm">
                    {isUploadingAvatar ? (
                      <div className="w-2 h-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Camera size={10} />
                    )}
                  </div>
                  <input type="file" className="hidden" accept="image/*" onChange={handleAvatarUpload} disabled={isUploadingAvatar} />
                </label>
                <span className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-wider">Photo (Optional)</span>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Full Name *</label>
                <input type="text" value={newPlayerFullName} onChange={e => setNewPlayerFullName(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm" placeholder="Player Name" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phone Number (Optional)</label>
                <input type="tel" value={newPlayerPhone} onChange={e => setNewPlayerPhone(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm" placeholder="Enter phone" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Date of Birth *</label>
                <input type="date" value={newPlayerDateOfBirth} onChange={e => setNewPlayerDateOfBirth(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm" />
              </div>
                            <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Gender</label>
                <select value={newPlayerGender} onChange={e => setNewPlayerGender(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm bg-white">
                  <option value="Men">Men</option>
                  <option value="Women">Women</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">District</label>
                <select value={newPlayerDistrict} onChange={e => setNewPlayerDistrict(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm bg-white">
                  {dbDistricts.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Primary Role</label>
                <select value={newPlayerPrimaryRole} onChange={e => setNewPlayerPrimaryRole(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm bg-white">
                  <option value="Batter">Batter</option>
                  <option value="Bowler">Bowler</option>
                  <option value="All-Rounder">All-Rounder</option>
                  <option value="Wicket Keeper">Wicket Keeper</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Batting Style</label>
                <select value={newPlayerBattingStyle} onChange={e => setNewPlayerBattingStyle(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm bg-white">
                  <option value="Right-Hand Bat">Right-Hand Bat</option>
                  <option value="Left-Hand Bat">Left-Hand Bat</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Bowling Style</label>
                <select value={newPlayerBowlingStyle} onChange={e => setNewPlayerBowlingStyle(e.target.value)} className="w-full border rounded-lg p-2.5 outline-none focus:border-cobalt text-sm bg-white">
                  <option value="None (Pure Batter)">None (Pure Batter)</option>
                  <option value="Right-Arm Fast">Right-Arm Fast</option>
                  <option value="Right-Arm Medium Fast">Right-Arm Medium Fast</option>
                  <option value="Right-Arm Off Spin">Right-Arm Off Spin</option>
                  <option value="Right-Arm Leg Spin">Right-Arm Leg Spin</option>
                  <option value="Left-Arm Fast">Left-Arm Fast</option>
                  <option value="Left-Arm Orthodox Spin">Left-Arm Orthodox Spin</option>
                  <option value="Left-Arm Chinaman">Left-Arm Chinaman</option>
                </select>
              </div>
            </div>
            <div className="p-4 border-t bg-slate-50 flex justify-end gap-2">
              <button onClick={() => setShowQuickRegister(false)} className="px-4 py-2 text-sm font-bold text-slate-500">Cancel</button>
              <button onClick={handleQuickRegister} disabled={!newPlayerFullName || !newPlayerDateOfBirth || isRegistering || isUploadingAvatar} className="px-4 py-2 text-sm font-bold bg-cobalt text-white rounded-lg disabled:opacity-50 flex items-center gap-2">
                {isRegistering ? 'Registering...' : 'Register Player'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}












